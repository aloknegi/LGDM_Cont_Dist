        order = 2; % Choose Gauss quadrature order      
        phi   = ls(sctr,1);
        [W,Q] = discontQ4quad(order,phi);  
        boundary_condition_nodes = [boundary_condition_nodes sctr_b_g sctr_q_g];

        for kk = 1 : size(W,1) 

        gpnt = gpnt + 1;
        e_tilde1 = kappa(iel,kk); % Non-equivalent strain     
        pt = Q(kk,:);   % Quadrature point       
        [N, N_a, B_a, J01] = xfemBmatrix1(pt,elemType1,iel,node1,element1); % B matrix and Jacobian for displacement vector         
        [N_p, B_p] = xfemBmatrix2(pt,elemType2,iel,node2,element2); % Shape Function
        [N_b, B_b] = xfemBmatrix3(pt,elemType1,iel,node1,element1,xCr_tot,enrich_node); 
        [N_q, B_q] = xfemBmatrix4(pt,elemType2,iel,node2,element2,xCr_tot,enrich_node);   

        gpt_locn = N'*node1(sctr,:);
        %         dist_H = signed_distance(xCr_tot,gpt_locn);
        %         H_gpt = heaviside_funct1(dist_H); 

        strain_gpt_l_a = B_a*u_l_node_a; % Computing Strain at Gaussian Point
        strain_gpt_l_b = B_b*u_l_node_b; % Computing Strain at Gaussian Point
        strain_gpt_nl_p = N_p*strain_nl_node_p; % Computing Non-local Strain vector at Quadrature point
        strain_gpt_nl_q = N_q*strain_nl_node_q; % Computing Additional Non-local Strain vector at Quadrature point
        del_strain_gpt_nl_p = B_p*strain_nl_node_p; % Computing gradient of Non-local Strain vector at Quadrature point
        del_strain_gpt_nl_q = B_q*strain_nl_node_q; % Computing gradient of Non-local Strain vector at Quadrature point

        strain_gpt_l = strain_gpt_l_a + strain_gpt_l_b; % Local Strain Vector
        strain_gpt_nl = strain_gpt_nl_p + strain_gpt_nl_q; % Nonlocal Strain Vector

        %         strain_gpt_l_check = [B_a B_b]*[u_l_node_a; u_l_node_b]; 
        %         strain_gpt_nl_check = [N_p N_q]*[strain_nl_node_p; strain_nl_node_q]; % Including both 
        %         strain_gpt_nl_check = strain_gpt_nl_p + H_gpt*N_p*strain_nl_node_q;
        %         if (strcmp(eqstrain_def,'VONMISES'))          
        %         [eps_nl_p, deps_de_nl_p] = Eq_Strain_VonMises(strain_gpt_nl_p, nu, K, stressState);              
        %         end     
        %         if (strcmp(eqstrain_def,'VONMISES'))       
        %         [eps_nl_q, deps_de_nl_q] = Eq_Strain_VonMises(strain_gpt_nl_q, nu, K, stressState);            
        %         end

        if (strcmp(eqstrain_def,'VONMISES'))

        [eps_nl, deps_de_nl] = Eq_Strain_VonMises(strain_gpt_nl, nu, K, stressState);        

        end       

        f = eps_nl - e_tilde1; % Damage Loading Function

        if f>=0
            kappa_gpt = eps_nl;
        else
            kappa_gpt = e_tilde1;
        end

        % Exponential Cohesive Law i.e Damage Evolution Law         
        Omega = compute_damage(kappa_gpt,kappa0_gpt,alpha,beta);

        % Coefficient Omega
        if kappa_gpt < kappa0_gpt            
            DomegaDk = 0;  
        elseif e_tilde1 < eps_nl
            DomegaDk = (kappa0_gpt*(alpha*exp(beta*(kappa0_gpt - kappa_gpt)) - alpha + 1))/kappa_gpt^2 + (alpha*beta*kappa0_gpt*exp(beta*(kappa0_gpt - kappa_gpt)))/kappa_gpt;  
        else
            DomegaDk = 0;
        end

        %------------------Constitutive Relations---------------------%
        sm_stress_gpt = (1-Omega)*De*strain_gpt_nl_p; % Smooth Stress Vector

        if sm_stress_gpt== zeros(3,1)
            sm_stress_gpt(1,1) = tol;
            sm_stress_gpt(2,1) = tol;
            sm_stress_gpt(3,1) = tol;
        end

        sigxx = sm_stress_gpt(1,1);  sigyy = sm_stress_gpt(2,1); sigxy = sm_stress_gpt(3,1);                         
        [sigma1, sigma2, theta] = Compute_Principal_Stress(sm_stress_gpt);
        [g, dgdomega] = interaction_function(eta,Omega,R); % Computing Interaction Function        
        c_len = (len_par^2);

        if (sigma1^2)>(sigma2^2)     
            den = (sigma1^2);         
            c11 = (sigxx^2 + sigxy^2); c22 = (sigyy^2 + sigxy^2);  c12 = (sigxy*(sigxx + sigyy));
            H_bar1 = [c11 c12; 
                      c12 c22]/den;              
            H_bar = [H_bar1 zeros(2,4);
                    zeros(2,2) H_bar1  zeros(2,2);
                    zeros(2,4) H_bar1];
        elseif (sigma2^2)>(sigma1^2)      
            den = (sigma2^2);
            c11 = (sigxx^2 + sigxy^2); c22 = (sigyy^2 + sigxy^2); c12 = (sigxy*(sigxx + sigyy));    
            H_bar1 = [c11 c12;
                      c12 c22]/den; 
            H_bar =  [H_bar1 zeros(2,4);
                     zeros(2,2) H_bar1  zeros(2,2);
                     zeros(2,4) H_bar1];      
        end

        stress_gpt_a = (1-Omega)*De*strain_gpt_l_a + hcoup*(strain_gpt_l_a - strain_gpt_nl_p);  % Stress corresponding to strain           
        stress_gpt_b = (1-Omega)*De*strain_gpt_l_b + hcoup*(strain_gpt_l_b - strain_gpt_nl_q);  % Stress corresponding to strain   
        stress_gpt = stress_gpt_a  +  stress_gpt_b;


        % Computing Stiffness Matrices  

        Coff_aa = B_a'*((1-Omega)*De + hcoup)*B_a;            
        Stif_aa = Stif_aa + Coff_aa*W(kk)*det(J01)*th;     

        Coff_ab = B_a'*((1-Omega)*De + hcoup)*B_b;            
        Stif_ab = Stif_ab + Coff_ab*W(kk)*det(J01)*th;      

        Coff_ap = -B_a'*(hcoup + De*strain_gpt_l*DomegaDk*deps_de_nl)*N_p;     
        Stif_ap = Stif_ap + Coff_ap*W(kk)*det(J01)*th;       

        Coff_aq = -B_a'*(hcoup + De*strain_gpt_l*DomegaDk*deps_de_nl)*N_q;  
        Stif_aq = Stif_aq + Coff_aq*W(kk)*det(J01)*th;         

        Coff_ba = B_b'*((1-Omega)*De + hcoup)*B_a;            
        Stif_ba = Stif_ba + Coff_ba*W(kk)*det(J01)*th;  

        Coff_bb = B_b'*((1-Omega)*De + hcoup)*B_b;            
        Stif_bb = Stif_bb + Coff_bb*W(kk)*det(J01)*th;   

        Coff_bp = -B_b'*(hcoup + De*strain_gpt_l*DomegaDk*deps_de_nl)*N_p;            
        Stif_bp = Stif_bp + Coff_bp*W(kk)*det(J01)*th; 

        Coff_bq = -B_b'*(hcoup + De*strain_gpt_l*DomegaDk*deps_de_nl)*N_q;   
        Stif_bq = Stif_bq + Coff_bq*W(kk)*det(J01)*th; 

        Coff_pa = -(N_p'*B_a);  
        Stif_pa = Stif_pa + Coff_pa*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);

        Coff_pb = -(N_p'*B_b);  
        Stif_pb = Stif_pb + Coff_pb*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);       

        %         Coff_pp =  N_p'*N_p + B_p'*g*c_len*H_bar*B_p + B_p'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl*N_p + B_p'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl*N_p;
        Coff_pp =  N_p'*N_p + B_p'*g*c_len*H_bar*B_p;
        Stif_pp = Stif_pp + Coff_pp*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);              

        %         Coff_pq =  N_p'*N_q + B_p'*g*c_len*H_bar*B_q + B_p'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl*N_q + B_p'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl*N_q; 
        Coff_pq =  N_p'*N_q + B_p'*g*c_len*H_bar*B_q; 
        Stif_pq = Stif_pq + Coff_pq*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);         

        Coff_qa = -(N_q'*B_a);  
        Stif_qa = Stif_qa + Coff_qa*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);

        Coff_qb = -(N_q'*B_b);  
        Stif_qb = Stif_qb + Coff_qb*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);            

        %         Coff_qp = N_q'*N_p + B_q'*g*c_len*H_bar*B_p + B_q'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl*N_p + B_q'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl*N_p; 
        Coff_qp = N_q'*N_p + B_q'*g*c_len*H_bar*B_p; 
        Stif_qp = Stif_qp + Coff_qp*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);         

        %         Coff_qq = N_q'*N_q + B_q'*g*c_len*H_bar*B_q + B_q'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl*N_q + B_q'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl*N_q;         
        Coff_qq = N_q'*N_q + B_q'*g*c_len*H_bar*B_q;                 
        Stif_qq = Stif_qq + Coff_qq*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);          

        fi_gpt_a = fi_gpt_a - (B_a'*stress_gpt)*W(kk)*det(J01)*th;
        fi_gpt_b = fi_gpt_b - (B_b'*stress_gpt)*W(kk)*det(J01)*th; 

        fstrain_gpt_p_temp = N_p'*(strain_gpt_nl_p + strain_gpt_nl_q - strain_gpt_l) + B_p'*g*c_len*(H_bar*del_strain_gpt_nl_p + H_bar*del_strain_gpt_nl_q);
        fstrain_gpt_q_temp = N_q'*(strain_gpt_nl_p + strain_gpt_nl_q - strain_gpt_l) + B_q'*g*c_len*(H_bar*del_strain_gpt_nl_p + H_bar*del_strain_gpt_nl_q);

        fstrain_gpt_p = fstrain_gpt_p - fstrain_gpt_p_temp*W(kk)*det(J01)*th;
        fstrain_gpt_q = fstrain_gpt_q - fstrain_gpt_q_temp*W(kk)*det(J01)*th;

        kappa(iel,kk) = kappa_gpt;        
        NE_gp(gpnt,1) = eps_nl;
        D_st(gpnt,1) = Omega;    
        stress_tot(gpnt,:) = stress_gpt;
        smooth_stress_tot(gpnt,:) = sm_stress_gpt;
        gauss_loc_wt_loc(gpnt,1:2) = gpt_locn;
        gauss_loc_wt_loc(gpnt,3) = W(kk);
        gauss_loc_wt_loc(gpnt,4) = det(J01); 
        check_damage(iel,kk) = Omega;        
        end                  % end of looping on GPs   