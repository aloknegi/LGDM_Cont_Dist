        % Choose Gauss quadrature rules for normal elements
        order = 2; 
        [W,Q] = quadrature(order,'GAUSS',2);        

        for kk = 1 : size(W,1) 

        gpnt = gpnt + 1;
        e_tilde1 = kappa(iel,kk); % Non-equivalent strain        
        pt = Q(kk,:);   % Quadrature point       
        [N, N_a, B_a, J01] = xfemBmatrix1(pt,elemType1,iel,node1,element1); % B matrix and Jacobian for displacement vector         
        [N_p, B_p] = xfemBmatrix2(pt,elemType2,iel,node2,element2); % Shape Function
        [N_b, B_b] = xfemBmatrix3(pt,elemType1,iel,node1,element1,xCr_tot); 
        [N_q, B_q] = xfemBmatrix4(pt,elemType2,iel,node2,element2,xCr_tot);          

        gpt_locn = N'*node1(sctr,:);
        strain_gpt_l_a = B_a*u_l_node_a; % Computing Strain at Gaussian Point
        strain_gpt_nl_p = N_p*strain_nl_node_p; % Computing Non-local Strain vector at Quadrature point
        del_strain_gpt_nl_p = B_p*strain_nl_node_p; % Computing gradient of Non-local Strain vector at Quadrature point

        if (strcmp(eqstrain_def,'VONMISES'))

        [eps_nl_p, deps_de_nl_p] = Eq_Strain_VonMises(strain_gpt_nl_p, nu, K, stressState);       

        end

        f = eps_nl_p - e_tilde1; % Damage Loading Function

        if f>=0
            kappa_gpt = eps_nl_p;
        else
            kappa_gpt = e_tilde1;
        end

        % Exponential Cohesive Law i.e Damage Evolution Law         
        Omega = compute_damage(kappa_gpt,kappa0_gpt,alpha,beta);

        %------------------Constitutive Relations---------------------%
        sm_stress_gpt = De*(1-Omega)*strain_gpt_nl_p; % Smooth Stress Vector
        %         sm_stress_gpt = De*(1-Omega)*strain_gpt_local; % Smooth Stress Vector

        if sm_stress_gpt== zeros(3,1)
            sm_stress_gpt(1,1) = tol;
            sm_stress_gpt(2,1) = tol;
            sm_stress_gpt(3,1) = tol;
        end

        sigxx = sm_stress_gpt(1,1); sigyy = sm_stress_gpt(2,1); sigxy = sm_stress_gpt(3,1);                         

        [sigma1, sigma2, theta] = Compute_Principal_Stress(sm_stress_gpt);
        ptheta = (pi/180)*theta;
        Rot = [cos(ptheta) -sin(ptheta); sin(ptheta) cos(ptheta)];

        [g,dgdomega] = interaction_function(eta,Omega,R); % Computing Interaction Function        

        c_len = (len_par^2);

        if (sigma1^2)>(sigma2^2)

        den = (sigma1^2);

        c11 = (sigxx^2 + sigxy^2);
        c22 = (sigyy^2 + sigxy^2);
        c12 = (sigxy*(sigxx + sigyy));

        Hbar1 = [c11 c12; 
                  c12 c22]/den; 

        H_bar = c_len*[Hbar1 zeros(2,4);
                zeros(2,2) Hbar1  zeros(2,2);
                zeros(2,4) Hbar1];


        elseif (sigma2^2)>(sigma1^2)

        den = (sigma2^2);

        c11 = (sigxx^2 + sigxy^2);
        c22 = (sigyy^2 + sigxy^2);
        c12 = (sigxy*(sigxx + sigyy));

        Hbar1 = [c11 c12;
                  c12 c22]/den; 

        H_bar =  c_len*[Hbar1 zeros(2,4);
                 zeros(2,2) Hbar1  zeros(2,2);
                 zeros(2,4) Hbar1];                      
        end               


        stress_gpt_a = (1-Omega)*De*strain_gpt_l_a + hcoup*(strain_gpt_l_a - strain_gpt_nl_p);  % Stress corresponding to strain           

        conjugate_stress_gpt_p = hcoup*(strain_gpt_nl_p - strain_gpt_l_a); % Conjugate Stress to Non-equivalent strain

        xit_gpt_p = hcoup*g*H_bar*del_strain_gpt_nl_p; % Conjugate Stress to Gradient of Non-equivalent strain

        % Coefficient Omega
        if kappa_gpt < kappa0_gpt            
            DomegaDk = 0;  
        elseif e_tilde1 < eps_nl_p
            DomegaDk = (kappa0_gpt*(alpha*exp(beta*(kappa0_gpt - kappa_gpt)) - alpha + 1))/kappa_gpt^2 + (alpha*beta*kappa0_gpt*exp(beta*(kappa0_gpt - kappa_gpt)))/kappa_gpt;  
        else
            DomegaDk = 0;
        end    

        % Computing Stiffness Matrices  

        Coff_aa = B_a'*((1-Omega)*De + hcoup)*B_a;

        Stif_aa = Stif_aa + Coff_aa*W(kk)*det(J01)*th;          

        Coff_ap = -B_a'*(hcoup + De*strain_gpt_l_a*DomegaDk*deps_de_nl_p)*N_p; 

        Stif_ap = Stif_ap + Coff_ap*W(kk)*det(J01)*th; % Stiffness matrix Kaa (8 x 4)

        Coff_pa = -(N_p'*hcoup*B_a);

        Stif_pa = Stif_pa + Coff_pa*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);

        Coff_pp = B_p'*hcoup*g*H_bar*B_p + N_p'*hcoup*N_p + B_p'*hcoup*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_p*N_p;

        Stif_pp = Stif_pp + (Coff_pp)*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 4)  

        Stif_ab = zeros(s_a,s_b); Stif_aq = zeros(s_a,s_q); 
        Stif_ba = zeros(s_b,s_a); Stif_bb = zeros(s_b,s_b); Stif_bp = zeros(s_b,s_p); Stif_bq = zeros(s_b,s_q);
        Stif_pb = zeros(s_p,s_b); Stif_pq = zeros(s_p,s_q);
        Stif_qa = zeros(s_q,s_a); Stif_qb = zeros(s_q,s_b); Stif_qp = zeros(s_q,s_p); Stif_qq = zeros(s_q,s_q);   

        fi_gpt_a = fi_gpt_a - (B_a'*stress_gpt_a)*W(kk)*det(J01)*th;
        fi_gpt_b = zeros(s_b,1);
        fstrain_gpt_p = fstrain_gpt_p - (N_p'*conjugate_stress_gpt_p + B_p'*xit_gpt_p)*W(kk)*det(J01)*th;
        fstrain_gpt_q = zeros(s_q,1); 

        kappa(iel,kk) = kappa_gpt;      
        NE_gp(gpnt,1) = eps_nl_p;
        D_st(gpnt,1) = Omega;   
        stress_tot(gpnt,:) = stress_gpt_a;
        smooth_stress_tot(gpnt,:) = sm_stress_gpt;
        gauss_loc_wt_loc(gpnt,1:2) = gpt_locn;
        gauss_loc_wt_loc(gpnt,3) = W(kk);
        gauss_loc_wt_loc(gpnt,4) = det(J01);
        check_damage(iel,kk) = Omega;    
        end                         