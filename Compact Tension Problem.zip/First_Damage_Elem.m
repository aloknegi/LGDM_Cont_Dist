function [cohesive_tip, counter_det] = First_Damage_Elem(check_damage)

counter = 1;
elem = [];

for i = 1:size(check_damage,1)
    
   damage_gp = check_damage(i,:);
   damage_count = 0;
   
   for j = 1:size(damage_gp,2)    
       Omega = check_damage(i,j);  
       if Omega > 0.9995
        damage_count = damage_count + 1;
       end
   end
   
   if damage_count == size(damage_gp,2) 
       elem(counter) = i;
       counter_det = 1;
       counter = counter + 1;
   end
end 

TF = isempty(elem);

if TF == 1
    
    counter_det = 0;
    cohesive_tip = [0 0];
    
else
    
    counter_det = 1;
    cohesive_tip = [12 48];
    
end

end