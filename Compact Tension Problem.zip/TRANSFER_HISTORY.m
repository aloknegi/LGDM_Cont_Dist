function [kappa] = TRANSFER_HISTORY(elem,kappa,node,element,sctr,ls,maxne)

% Transfer from old gauss points to nodes
% order = 2;
% [W,Q] = quadrature(order,'GAUSS',2);
% kappa_node = zeros(4,1);
% tran_mat = zeros(4,4);
% elemType = 'Q4' ;
% 
% for kk = 1 : size(W,1)  
%     
%     pt = Q(kk,:);   % Quadrature point 
%     [N, J0] = Bmatrix(pt,elemType,elem,node,element); % B matrix and Jacobian for displacement vector 
%     tran_mat = tran_mat + (N*N')*W(kk)*det(J0);
% 
% end
% 
% for kk = 1 : size(W,1)
%     
%     e_tilde1 = kappa(elem,kk); % Non-equivalent strain     
%     pt = Q(kk,:);   % Quadrature point 
%     [N, J0] = Bmatrix(pt,elemType,elem,node,element); % B matrix and Jacobian for displacement vector 
%     kappa_node = kappa_node + inv(tran_mat)*(N*e_tilde1)*W(kk)*det(J0);
%     
% end

% Transfer from node to new gauss points
order = 3; % Choose Gauss quadrature order      
phi   = ls(sctr,1);
subTriDiv = 0 ;
intType = 'TRIANGULAR' ;        %options: TRIANGULAR or DUNAVANT
[W,Q] = disSplitQ4(order,phi,subTriDiv,intType);
        
% for kk = 1:(size(W,1)) 
%         
%     pt = Q(kk,:);   % Quadrature point 
%     [N, J0] = Bmatrix(pt,elemType,elem,node,element); % B matrix and Jacobian for displacement vector 
%     kappa_new = N'*kappa_node;
%     kappa(elem,kk) = kappa_new;
%     
% end
kappa(elem,1:size(W,1)) = maxne;  

end


function [N,J0] = Bmatrix(pt,elemType,e,node1,element)

sctr = element(e,:);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
J0 = node1(sctr,:)'*dNdxi;                 % element Jacobian matrix

end              % end of switch 

function [W,Q]=discontQ4quad(order,phi)

        corner = [1 2 3 4 1];
        node   = [-1 -1; 1 -1; 1 1; -1 1];

        % loop on element edges
        for i = 1 : 4
            n1 = corner(i);
            n2 = corner(i+1);
            if ( phi(n1)*phi(n2) < 0 )
                r    = phi(n1)/(phi(n1)-phi(n2));
                pnt  = (1-r)*node(n1,:)+r*node(n2,:);
                node = [node;pnt];
            end
        end

        % get decompused triangles
        tri = delaunay(node(:,1),node(:,2));
        tri = tricheck(node,tri);

        % loop over subtriangles to get quadrature points and weights
        pt = 1;
        for e = 1:size(tri,1)
            [w,q]=quadrature(order,'TRIANGULAR',2);
            % transform quadrature points into the parent element
            coord = node(tri(e,:),:);
            a = det([coord,[1;1;1]])/2;
            if ( a<0 )  % need to swap connectivity
                coord = [coord(2,:);coord(1,:);coord(3,:)];
                a = det([coord,[1;1;1]])/2;
            end

            if ( a~=0 )
                for n=1:length(w)
                    N=lagrange_basis('T3',q(n,:));
                    Q(pt,:) = N'*coord;
                    W(pt,1) = 2*w(n)*a;
                    pt = pt+1;
                end
            end

        end
end


function conn=tricheck(node,conn,verbose)

% FUNCTION
% conn=tricheck(node,conn,verbose)
% This function check wether a triangle has a negative Jacobian, and if
% so reorders it so that the the Jacobian is positive.

    if ( nargin==2 )
        verbose=0;
    end

    if ( size(node,2)==3 )
        node=node(:,1:2);
    end

    count=0;

    for e=1:size(conn,1)

        sctr=conn(e,:);
        [N,dNdxi]=lagrange_basis('T3',[1/3 1/3]);
        detJ=det(node(sctr,:)'*dNdxi);

        if ( detJ < 0 )
            %disp(['NEGATIVE JACOBIAN IN ELEMENT ',num2str(e)])
            conn(e,:)=fliplr(sctr);
            count=count+1;
        elseif ( detJ == 0 )
            disp(['ZERO JACOBIAN IN ELEMENT ',num2str(e),' CANNOT FIX'])
        end
    end

    if ( verbose )
        disp(['TRICHECK FOUND ',num2str(count),' NEGATIVE JACOBIANS, ALL FIXED'])
    end
end
