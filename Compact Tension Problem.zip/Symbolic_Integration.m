clear; close all;
syms kappa_gpt kappa0_gpt kc kappa_crt E alpha_coh beta_coh u_crt len_scale
a = (kappa0_gpt/kappa_gpt);
b = kappa_gpt - kappa0_gpt;
c = kappa_crt - kappa0_gpt;      
Omega = 1 - a*exp(-(b/c));
Sigma = (1-Omega)*E*kappa_gpt;
phi_1temp = int(Sigma,kappa_gpt,kappa0_gpt,kc);
phi_1 = simplify(phi_1temp);


assume(kappa_crt>kappa0_gpt)
phi_2temp = int(Sigma,kappa_gpt,kc,Inf);
phi_3 = simplify(phi_2temp);

phi_2 = (alpha_coh - alpha_coh*exp(-beta_coh*u_crt))/beta_coh;
phi_4 = (alpha_coh*exp(-beta_coh*u_crt))/beta_coh;

t_crt = alpha_coh*exp(-beta_coh*u_crt);
a1 = (kappa0_gpt/kc);
b1 = kc - kappa0_gpt;
omega_crt = 1 - a1*exp(-(b1/c));
sigma_crt = (1-omega_crt)*E*kc;

phi_1 = phi_1*len_scale;
phi_3 = phi_3*len_scale;
f1 = phi_2 - phi_1;
f2 = phi_4 - phi_3;
f3 = sigma_crt - t_crt;
a11 = diff(f1,alpha_coh);
a12 = diff(f1,beta_coh);
a13 = diff(f1,u_crt);
a21 = diff(f2,alpha_coh);
a22 = diff(f2,beta_coh);
a23 = diff(f2,u_crt);
a31 = diff(f3,alpha_coh);
a32 = diff(f3,beta_coh);
a33 = diff(f3,u_crt);
del_f = [a11 a12 a13; a21 a22 a23; a31 a32 a33]
check = 0;

