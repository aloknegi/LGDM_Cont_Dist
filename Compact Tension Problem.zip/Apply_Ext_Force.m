ext_load = 200;
% ext_load_right = (10/11)*ext_load;
% ext_load_left = (1/11)*ext_load;
ext_load_right = (10/11)*100;
ext_load_left = (1/11)*100;

F_ext_tot(dofs_ext_nodes_right) = ext_load_right*h;
F_ext_tot(dofs_ext_nodes_left) = ext_load_left*h;

% ascend_x = sort(node1(extdisp_nodes_right,1));
% for ii = 1:length(extdisp_nodes_right)-1
%     x_1 = ascend_x(ii);
%     num_1 = find(x_1 == node1(extdisp_nodes_right,1));
%     x_2 = ascend_x(ii+1);
%     num_2 = find(x_2 == node1(extdisp_nodes_right,1));
%     sort_extdisp_nodes_right(ii,:) = [extdisp_nodes_right(num_1) extdisp_nodes_right(num_2)];
% end
% 
% [W,Q]=quadrature(1,'GAUSS',1);
% 
% for e = 1:size(sort_extdisp_nodes_right,1)
%     sctr = sort_extdisp_nodes_right(e,:);
%     sctry = sctr.*2 ;
% 
%     for ij=1:size(W,1)
%         pt = Q(ij,:);
%         wt = W(ij);
%         N  = lagrange_basis('L2',pt);
%         J0 = abs(node1(sctr(2)) - node1(sctr(1)))/2;
%         temp = N*ext_load_right*det(J0)*wt;
%         F_ext_tot(sctry) = F_ext_tot(sctry) + temp;
%     end   % of quadrature loop
% end       % of element loop

% ascend_x = sort(node1(extdisp_nodes_left,1));
% for ii = 1:length(extdisp_nodes_left)-1
%     x_1 = ascend_x(ii);
%     num_1 = find(x_1 == node1(extdisp_nodes_left,1));
%     x_2 = ascend_x(ii+1);
%     num_2 = find(x_2 == node1(extdisp_nodes_left,1));
%     sort_extdisp_nodes_left(ii,:) = [extdisp_nodes_left(num_1) extdisp_nodes_left(num_2)];
% end
% 
% [W,Q]=quadrature(1,'GAUSS',1);
% 
% for e = 1:size(sort_extdisp_nodes_left,1)
%     sctr = sort_extdisp_nodes_left(e,:);
%     sctry = sctr.*2;
% 
%     for ij=1:size(W,1)
%         pt = Q(ij,:);
%         wt = W(ij);
%         N  = lagrange_basis('L2',pt);
%         J0 = abs(node1(sctr(2)) - node1(sctr(1)))/2;
%         temp = N*ext_load_left*det(J0)*wt*h;
%         F_ext_tot(sctry) = F_ext_tot(sctry) + temp;
%     end   % of quadrature loop
% end       % of element loop
