function [xCr_tot_new, split_elems, tip_elems, cohesive_tip_new, crack_angle_new, ls, enrich_node, kappa, ElCrk,check_new_split, new_split_no, crack_inc_count, tip_edge_nodes] = FIND_SPLIT_ELEMENTS_NEW1(material_p, damage_p, xCr_tot_old, cohesive_tip_old, split_elems, tip_elems,  node, element, ne_gp_tot, damage_gp_tot, check_damage, Gpnt_Wt_detJ, crack_angle_old, ls, enrich_node, kappa, ElCrk_old, crack_inc_count, tip_edge_nodes_old)

len_par = material_p(1,3); % Length Scale Parameter
check_new_split = 0;
new_split_no = 0;
omega_crit = material_p(1,8);
rot = crack_angle_old;
tol = 1e-25;
x = Gpnt_Wt_detJ(:,1);
y = Gpnt_Wt_detJ(:,2);
wt_tot = Gpnt_Wt_detJ(:,3);
detJ_tot = Gpnt_Wt_detJ(:,4);
x0 = cohesive_tip_old(1,1);
y0 = cohesive_tip_old(1,2);
r0 = 2*len_par; %Defining radius limit of sector in front of crack tip
th1 = deg2rad(-90 + rot);
th2 = deg2rad(90 + rot);

if th1 > pi & th2 > pi
    [theta, rho] = cart2pol_0to360(x - x0, y - y0);
    select = (rho < r0) & (th1 < theta) & (theta < th2);
elseif th2 > pi
    [theta, rho] = cart2pol_0to360(x - x0, y - y0);
    select = (rho < r0) & (th1 < theta) & (theta < th2);
else
    [theta, rho] = cart2pol_0to180(x - x0, y - y0);
    select = (rho < r0) & (th1 < theta) & (theta < th2);
end

xs = x(select);
ys = y(select);
wt_tri = wt_tot(select);
detJ_tri = detJ_tot(select);
gauss_loc = [xs ys];
ne_tot =  ne_gp_tot(select);
total_gpt = size(xs,1);
% 
% figure
% plot(x,y,'ob', xs,ys,'or');

inc_length = 2*len_par;
d_avg = [0 0];
sum = 0;
new_segment = [];

for j = 1:total_gpt
    pt2 = gauss_loc(j,:);
    dist = norm(pt2 - cohesive_tip_old);
    con_wj = (1/((2*pi)^1.5))*(r0^3);
    aa_wj = (-dist^2)/(2*(r0^2));
    wj = con_wj*exp(aa_wj);  % Nonlocal weight function    
    detJ = detJ_tri(j,1);
    wt_gp = wt_tri(j,1); % Weight of the gauss point
    ne_gp = ne_tot(j,1); % Damage value at a gauss point
    dirn = pt2 - cohesive_tip_old; % Direction from the cohesive tip
   
    if dist == 0
        dist = tol;
    end
   
    sum = sum + wt_gp*wj*detJ;
    d_avg = d_avg + wt_gp*ne_gp*(dirn/dist)*wj*detJ;
end

d_vector = (d_avg/sum);
d_vector = d_vector./norm(d_vector); % Unit Vector in the direction
d_check = (d_vector)*(inc_length);
angle = (atan2(d_avg(1,2),d_avg(1,1)))*(180/pi);
new_crack_tip_temp = [(x0 + d_check(1,1)) (y0 + d_check(1,2))];
new_segm = [cohesive_tip_old; new_crack_tip_temp];

[tipEl, splitEl, splitelem_inter, ElCrk_temp] = CRACKDETECT(new_segm,node,element,ElCrk_old);

check_split = isempty(splitEl); % Check for split elements
split_elems_new = [];

if check_split == 0
    
    for i_ss = 1:size(splitEl,1)
        intersect1 = ElCrk_temp(splitEl(i_ss),1:2);
        intersect2 = ElCrk_temp(splitEl(i_ss),3:4);
        check1 = (intersect1(:,1) - x0).^2 + (intersect1(:,2) - y0).^2; % distance form point (xo,y0)
        check2 = (intersect2(:,1) - x0).^2 + (intersect2(:,2) - y0).^2; % distance form point (xo,y0)
        
        if check1 > check2
            splitelem_inter(2*i_ss -1,:) = intersect2;
            splitelem_inter(2*i_ss,:) = intersect1;
            ElCrk_temp(splitEl(i_ss),1:2) = intersect2;
            ElCrk_temp(splitEl(i_ss),3:4) = intersect1;
        else
            splitelem_inter(2*i_ss -1,:) = intersect1;
            splitelem_inter(2*i_ss,:) = intersect2;
            ElCrk_temp(splitEl(i_ss),1:2) = intersect1;
            ElCrk_temp(splitEl(i_ss),3:4) = intersect2;           
        end
    end   
    
    xCr_tot_new = xCr_tot_old;
    sort_coordinates = splitelem_inter(2:2:size(splitelem_inter,1),:);
    sortval = (sort_coordinates(:,1) - x0).^2 + (sort_coordinates(:,2) - y0).^2; % distance form point (xo,y0)
    [~,sortorder] = sort(sortval);
    sorted_split_elems = splitEl(sortorder,:);
    temp_split_elems_new = [];
    
    for i_se = 1:size(sorted_split_elems,1)      
        check_elem = sorted_split_elems(i_se);
        tf = CHECK_DAMAGE_ELEMENT1(check_elem,check_damage,omega_crit);
        check_member = ismember(check_elem,split_elems);        
        if tf == 1 && check_member == 0 
            temp_split_elems_new = [temp_split_elems_new; check_elem];
        elseif tf == 0  
            break;
        end       
    end
       
    check_split_new = isempty(temp_split_elems_new); % Check for split elements
    size_splt_new = size(temp_split_elems_new,1);
    
    if check_split_new == 0 && size_splt_new >= 2
    
        check_new_split = 2;
        crack_angle_new = angle;        
        ElCrk_new_updated = ElCrk_temp;     
        ElCrk = ElCrk_new_updated;
        counter = 0;
        
        for ii = 1:2 % Check for new split elements
            check_elem = temp_split_elems_new(ii);
            crack_coord = [ElCrk_temp(check_elem ,1:2); ElCrk_temp(check_elem,3:4)]; % Intersection points in the quad element
            sortval = (crack_coord(:,1) - x0).^2 + (crack_coord(:,2) - y0).^2; % distance form point (xo,y0)
            [~,sortorder] = sort(sortval);
            sort_coordinates = crack_coord(sortorder,:);            
            cohesive_tip_new = sort_coordinates(2,:);
            xCr_tot_new = [xCr_tot_new; cohesive_tip_new];
            counter = counter + 1;
        end
        
        new_segment = [cohesive_tip_old; cohesive_tip_new];  
        
        figure
        elemType1 = 'Q4';
        cntr = plot([0,200,200,0,0],[0,0,200,200,0],'k-');
        set(cntr,'LineWidth',2);        
        plot_mesh(node,element,elemType1,'k-');
        set(gcf, 'color', 'white');
        hold on
        chr = plot(new_segment(:,1),new_segment(:,2),'r-');
        set(chr,'LineWidth',3);
        axis equal
        axis off   
               
        
        tip_elem_new = temp_split_elems_new(counter);
        last_split_elem = temp_split_elems_new(counter-1);
        [tip_edge_nodes_new] = ZERO_ADD_DOF(tip_elem_new,cohesive_tip_new, node, element);
        
        split_elems_new = temp_split_elems_new(1:counter);
        split_elems = [split_elems;  split_elems_new];
        split_nodes = unique(element(split_elems_new,:));
        enrich_node(split_nodes) = 1;
        
        acommon = intersect(tip_edge_nodes_new,element(last_split_elem,:)); 
        tip_edge_nodes = setdiff(tip_edge_nodes_new,acommon);
        enrich_node(tip_edge_nodes) = 0;
            
        for ss = 1:1:(size(split_elems_new,1))
            
            ss_elem = split_elems_new(ss);
            maxne = max(kappa(ss_elem,:));  

            sctr = element(ss_elem,:);
            new_split_no = new_split_no + 1;
            segment_elem = [ElCrk(ss_elem,1:2); ElCrk(ss_elem,3:4)];
            x0 = segment_elem(1,1); y0 = segment_elem(1,2);
            x1 = segment_elem(2,1); y1 = segment_elem(2,2);
            EPS = 1e-08 ;
            
                for il = 1:size(sctr,2) % Computing level set for delunuay triangulization
                    i_sctr = sctr(il);    
                    x = node(i_sctr,1);
                    y = node(i_sctr,2);
                    l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
                    phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0);
%                     ls(i_sctr,1) = phi/l;  
                    if abs(phi) < EPS
                        ls(i_sctr,1) = 0 ;
                    else
                        ls(i_sctr,1) = phi/l;
                    end
                end
                
%             kappa = TRANSFER_HISTORY(ss_elem,kappa,node,element,sctr,ls,maxne);
            kappa(ss_elem,:) = maxne;     
                
        end
                
        crack_inc_count = crack_inc_count + 1;
        tip_elems{crack_inc_count} = tip_elem_new;
             
            
    else
        
        split_elems_new = [];
        cohesive_tip_new = cohesive_tip_old;
        crack_angle_new = crack_angle_old;
        xCr_tot_new = xCr_tot_old;
        ElCrk = ElCrk_old;
        split_elems = [split_elems;  split_elems_new];
        tip_edge_nodes = tip_edge_nodes_old;
            
    end
       
else
        split_elems_new = [];
        cohesive_tip_new = cohesive_tip_old;
        crack_angle_new = crack_angle_old;
        xCr_tot_new = xCr_tot_old;
        ElCrk = ElCrk_old;
        split_elems = [split_elems;  split_elems_new];
        tip_edge_nodes = tip_edge_nodes_old;
end
 


end




function [th,r,z] = cart2pol_0to180(x,y,z)
%CART2POL Transform Cartesian to polar coordinates.
%   [TH,R] = CART2POL(X,Y) transforms corresponding elements of data
%   stored in Cartesian coordinates X,Y to polar coordinates (angle TH
%   and radius R).  The arrays X and Y must be the same size (or
%   either can be scalar). TH is returned in radians.
%
%   [TH,R,Z] = CART2POL(X,Y,Z) transforms corresponding elements of
%   data stored in Cartesian coordinates X,Y,Z to cylindrical
%   coordinates (angle TH, radius R, and height Z).  The arrays X,Y,
%   and Z must be the same size (or any of them can be scalar).  TH is
%   returned in radians.
%
%   Class support for inputs X,Y,Z:
%      float: double, single
%
%   See also CART2SPH, SPH2CART, POL2CART.

%   Copyright 1984-2005 The MathWorks, Inc.

th = atan2(y,x);
r = hypot(x,y);
end


function [th,r,z] = cart2pol_0to360(x,y,z)
%CART2POL Transform Cartesian to polar coordinates.
%   [TH,R] = CART2POL(X,Y) transforms corresponding elements of data
%   stored in Cartesian coordinates X,Y to polar coordinates (angle TH
%   and radius R).  The arrays X and Y must be the same size (or
%   either can be scalar). TH is returned in radians.
%
%   [TH,R,Z] = CART2POL(X,Y,Z) transforms corresponding elements of
%   data stored in Cartesian coordinates X,Y,Z to cylindrical
%   coordinates (angle TH, radius R, and height Z).  The arrays X,Y,
%   and Z must be the same size (or any of them can be scalar).  TH is
%   returned in radians.
%
%   Class support for inputs X,Y,Z:
%      float: double, single
%
%   See also CART2SPH, SPH2CART, POL2CART.

%   Copyright 1984-2005 The MathWorks, Inc.

th = atan2(y,x);
th = wrapTo2Pi(th);
r = hypot(x,y);
end

function [edge_nodes] = ZERO_ADD_DOF(tip_elem,cohesive_tip, node, element)

sctr = element(tip_elem,:);
numEdge = size(sctr,2);
coords = node(sctr,:);
edge_nodes = zeros(1,2);
corner = [1 2 3 4 1];
% tol = 1.065e-5;

for iedge = 1:numEdge    
    n1 = corner(iedge); n2 = corner(iedge+1); 
    edge_coord = coords([n1 n2],:);
    x1 = edge_coord(1,1); y1 = edge_coord(1,2); 
    x2 = edge_coord(2,1); y2 = edge_coord(2,2);
    x3 = cohesive_tip(1,1); y3 = cohesive_tip(1,2);
    
    P1 = [x1 y1];
    P2 = [x2 y2];
    Q = [x3 y3];
    P12 = P2 - P1;
    L12 = sqrt(P12 * P12');
    N   = P12 / L12;
    % Line from P1 to Q:
    PQ = Q - P1;
    % Norm of distance vector: LPQ = N x PQ
    Dist = abs(N(1) * PQ(2) - N(2) * PQ(1));
    % Consider rounding errors:
    Limit = 500 * eps(max(abs(cat(1, P1(:), P2(:), Q(:)))));
    R     = (Dist < Limit);
    
    if R == 1
        edge_nodes(1,1) = sctr(n1);
        edge_nodes(1,2) = sctr(n2);
    end
    
    % Consider end points if any 4th input is used:
%     if R && nargin == 4
%       % Projection of the vector from P1 to Q on the line:
%       L = PQ * N.';  % DOT product
%       R = (L > 0.0 && L < L12);
%     end



%     m = (y2-y1)/(x2-x1);
%     b = y1 - m*x1;
%     yy3 = m*x3 + b;
%     check = y3 - yy3;
%     if check <= tol
%         edge_nodes(1,1) = sctr(n1);
%         edge_nodes(1,2) = sctr(n2);
%     end
    
end %end iedge loop
end