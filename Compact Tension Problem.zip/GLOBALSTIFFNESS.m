function [R, Kres_k, active_dof] = GLOBALSTIFFNESS(tA_total, Q_ext, material_p, damage_p, numelem, dofs, node1, element1,...
    element2, node2, elemType1, elemType2, kappa, split_elems, tip_elements, ElCrk, ls, enrich_node, De1, De2,...
        eqstrain_def, stressState, damage_evol_def,xCr_tot,stiff_elements,tip_edge_nodes)

u_dof = dofs{5};
add_u_dof = dofs{6};
strain_dof = dofs{7};
add_strain_dof = dofs{8};
add_dof = [add_u_dof; add_strain_dof];
fixed_dof_y = dofs{3}; 
fixed_dof_x = dofs{4}; 

total_disp = size(u_dof,1);
add_disp = size(add_u_dof,1);
total_strain = size(strain_dof,1);
add_strain = size(add_strain_dof,1);

total_unknown = total_disp + add_disp + total_strain + add_strain; % Total Unknowns
total_dof = [u_dof; add_u_dof; strain_dof; add_strain_dof];

u_tot = tA_total(u_dof);
add_u_tot = tA_total(add_u_dof);
strain_tot = tA_total(strain_dof);
add_strain_tot = tA_total(add_strain_dof);
lambda = tA_total(end);

%-----------------Damage Parameters---------------------%
K = damage_p(1,1); 
alpha = damage_p(1,2);
beta = damage_p(1,3);
kappa_crt = damage_p(1,4);
R = damage_p(1,5);
eta = damage_p(1,6);

%-----------------Material Parameters-------------------%
nu = material_p(1,1); % Poisson Ratio
% E  = material_p(1,2); % Elastic Moduli
len_par = material_p(1,3); % Length Scale Parameter
th = material_p(1,4); % Thickness of the Specimen
% ft = material_p(1,5);  % Tensile Strength in MPa
hcoup = material_p(1,6);
kappa0_gpt_m = material_p(1,7); 
kappa0_stiff_m = material_p(1,10); 
omega_crit = material_p(1,8); 

tol = 1e-25; % Tolerance
fi_a = zeros(total_disp,1); % Internal Force vector corresponding to normal displacements
fi_b = zeros(add_disp,1); % Internal Force vector corresponding to additional displacements
fstrain_p = zeros(total_strain,1); % Internal Force vector corresponding to Nonlocal Strains
fstrain_q = zeros(add_strain,1); % Internal Force vector corresponding to additional Nonlocal Strains
I = zeros(1600*numelem,1);
J =  zeros(1600*numelem,1);
S = zeros(1600*numelem,1);
index = 0; gpnt = 0;
boundary_condition_nodes = [];
total_zero_add_disp_dof = [];

for iel = 1:numelem % Loop on elements  
        
        sctr = element2(iel,:); % Element connectivity 
        
        % Local and Global numbering for normal displacements will be same
        sctr_a_l = assembly(iel,element1); % Local Numbering and Global numbering for displacements 
        sctr_a_g = sctr_a_l; % Local Numbering and Global numbering for displacements 
        sctr_b_l = sctr_a_l; % Local Numbering for Additional displacements 
        sctr_b_g = sctr_a_l + total_disp; % Global Numbering for Additional displacements 

        sctr_p_g = assembly_nonlocal(sctr, total_disp, add_disp); % Global numbering for Strains 
        sctr_p_l = sctr_p_g - total_disp - add_disp; % Local Numbering for Strains
        sctr_q_g = sctr_p_l + total_disp + add_disp + total_strain; % Global numbering for additional Strains 
        sctr_q_l = sctr_p_l; % Local Numbering for additional Strains

        u_l_node_a = u_tot(sctr_a_l,:);  % Displacement corresponding to each node of the element 
        u_l_node_b = add_u_tot(sctr_b_l,:);  % Additional Displacement corresponding to each node of the element 
        strain_nl_node_p = strain_tot(sctr_p_l,:); % Non-local Strain corresponding to each node of the element
        strain_nl_node_q = add_strain_tot(sctr_q_l,:); % Additional Non-local Strain corresponding to each node of the element

        s_a = size(u_l_node_a,1); % Size of local displacements
        s_b = size(u_l_node_b,1); % Size of Additional Displacement 
        s_p = size(strain_nl_node_p,1); % Size of Non-local Strain
        s_q = size(strain_nl_node_q,1); % Size of Additional Non-local Strain

        Stif_aa = zeros(s_a,s_a); Stif_ab = zeros(s_a,s_b); Stif_ap = zeros(s_a,s_p); Stif_aq = zeros(s_a,s_q);
        Stif_ba = zeros(s_b,s_a); Stif_bb = zeros(s_b,s_b); Stif_bp = zeros(s_b,s_p); Stif_bq = zeros(s_b,s_q);
        Stif_pa = zeros(s_p,s_a); Stif_pb = zeros(s_p,s_b); Stif_pp = zeros(s_p,s_p); Stif_pq = zeros(s_p,s_q);
        Stif_qa = zeros(s_q,s_a); Stif_qb = zeros(s_q,s_b); Stif_qp = zeros(s_q,s_p); Stif_qq = zeros(s_q,s_q);   

        fi_gpt_a = zeros(s_a,1);
        fi_gpt_b = zeros(s_b,1);
        fstrain_gpt_p = zeros(s_p,1);  
        fstrain_gpt_q = zeros(s_q,1); 
        
    if (ismember(iel,split_elems))    
        
        order = 3; % Choose Gauss quadrature order      
        phi   = ls(sctr,1);
        subTriDiv = 0 ;
        intType = 'TRIANGULAR' ;        %options: TRIANGULAR or DUNAVANT
        [W,Q] = disSplitQ4(order,phi,subTriDiv,intType);
        
        
        if (ismember(iel,split_elems))
        boundary_condition_nodes = [boundary_condition_nodes sctr_b_g sctr_q_g];
        end        

        for kk = 1:(size(W,1)) 

        gpnt = gpnt + 1;       
        pt = Q(kk,:);   % Quadrature point 
        crk_seg = [ElCrk(iel,1:2); ElCrk(iel,3:4)]; % Intersection points in the quad element
        
        [N, N_a, B_a, J01] = xfemBmatrix1(pt,elemType1,iel,node1,element1); % B matrix and Jacobian for displacement vector         
        [N_p, B_p] = xfemBmatrix2(pt,elemType2,iel,node2,element2); % Shape Function
        [N_b, B_b] = xfemBmatrix3(pt,elemType1,iel,node1,element1,crk_seg,enrich_node); 
        [N_q, B_q] = xfemBmatrix4(pt,elemType2,iel,node2,element2,crk_seg,enrich_node);   

        gpt_locn = N'*node1(sctr,:);
        strain_gpt_l_a = B_a*u_l_node_a; % Computing Strain at Gaussian Point
        strain_gpt_l_b = B_b*u_l_node_b; % Computing Strain at Gaussian Point
        strain_gpt_nl_p = N_p*strain_nl_node_p; % Computing Non-local Strain vector at Quadrature point
        strain_gpt_nl_q = N_q*strain_nl_node_q; % Computing Additional Non-local Strain vector at Quadrature point
        del_strain_gpt_nl_p = B_p*strain_nl_node_p; % Computing gradient of Non-local Strain vector at Quadrature point
        del_strain_gpt_nl_q = B_q*strain_nl_node_q; % Computing gradient of Non-local Strain vector at Quadrature point
        strain_gpt_l = strain_gpt_l_a + strain_gpt_l_b; % Local Strain Vector
        strain_gpt_nl = strain_gpt_nl_p + strain_gpt_nl_q; % Nonlocal Strain Vector


        if (strcmp(eqstrain_def,'VONMISES'))

        [eps_nl, deps_de_nl] = Eq_Strain_VonMises(strain_gpt_nl, nu, K, stressState);  
        [eps_nl_p , deps_de_nl_p] = Eq_Strain_VonMises(strain_gpt_nl_p, nu, K, stressState); 
        [eps_nl_q , deps_de_nl_q] = Eq_Strain_VonMises(strain_gpt_nl_q, nu, K, stressState); 
        
        elseif (strcmp(eqstrain_def,'MAZARS'))

        [eps_nl, deps_de_nl] = Eq_Strain_Mazars_Def(strain_gpt_nl, nu);        

        end 
     
        Omega = omega_crit;
        DomegaDk = 0; % Freezing split element
         
        [g_int, dgdomega] = interaction_function(eta,Omega,R);          % Computing Interaction Function        
        dgdomega = 0;
        
        %------------------Constitutive Relations---------------------%
        sm_stress_gpt = De*strain_gpt_nl_p; % Smooth Stress Vector
%         sm_stress_gpt = (1-Omega)*De*strain_gpt_nl;
        
        if sm_stress_gpt== zeros(3,1)
            sm_stress_gpt(1,1) = tol;
            sm_stress_gpt(2,1) = tol;
            sm_stress_gpt(3,1) = tol;
        end

        sigxx = sm_stress_gpt(1,1);  sigyy = sm_stress_gpt(2,1); sigxy = sm_stress_gpt(3,1);                         
        [sigma1, sigma2, theta] = Compute_Principal_Stress(sm_stress_gpt);   
        c_len = (len_par^2);

        if (sigma1^2)>(sigma2^2)     
            den = (sigma1^2);         
            c11 = (sigxx^2 + sigxy^2); c22 = (sigyy^2 + sigxy^2);  c12 = (sigxy*(sigxx + sigyy));
            H_bar1 = [c11 c12; 
                      c12 c22]/den;              
            H_bar = [H_bar1 zeros(2,4);
                    zeros(2,2) H_bar1  zeros(2,2);
                    zeros(2,4) H_bar1];
                
        elseif (sigma2^2)>(sigma1^2)      
            den = (sigma2^2);
            c11 = (sigxx^2 + sigxy^2); c22 = (sigyy^2 + sigxy^2); c12 = (sigxy*(sigxx + sigyy));    
            H_bar1 = [c11 c12;
                      c12 c22]/den; 
            H_bar =  [H_bar1 zeros(2,4);
                     zeros(2,2) H_bar1  zeros(2,2);
                     zeros(2,4) H_bar1];      
        end

        stress_gpt_a = (1-Omega)*De*strain_gpt_l_a;  % Stress corresponding to strain           
        stress_gpt_b = (1-Omega)*De*strain_gpt_l_b;  % Stress corresponding to strain   
        stress_gpt = stress_gpt_a  +  stress_gpt_b;

        % Computing Stiffness Matrices  

        Coff_aa = B_a'*((1-Omega)*De)*B_a;            
        Stif_aa = Stif_aa + Coff_aa*W(kk)*det(J01)*th;     

        Coff_ab = B_a'*((1-Omega)*De)*B_b;            
        Stif_ab = Stif_ab + Coff_ab*W(kk)*det(J01)*th;      

        Coff_ap = -B_a'*(De*strain_gpt_l*DomegaDk*deps_de_nl_p)*N_p;     
        Stif_ap = Stif_ap + Coff_ap*W(kk)*det(J01)*th;       

        Coff_aq = -B_a'*(De*strain_gpt_l*DomegaDk*deps_de_nl_q)*N_q;  
        Stif_aq = Stif_aq + Coff_aq*W(kk)*det(J01)*th;         

        Coff_ba = B_b'*((1-Omega)*De)*B_a;            
        Stif_ba = Stif_ba + Coff_ba*W(kk)*det(J01)*th;  

        Coff_bb = B_b'*((1-Omega)*De)*B_b; 
        Stif_bb = Stif_bb + (Coff_bb)*W(kk)*det(J01)*th;   
            
        Coff_bp = -B_b'*(De*strain_gpt_l*DomegaDk*deps_de_nl_p)*N_p;            
        Stif_bp = Stif_bp + Coff_bp*W(kk)*det(J01)*th; 

        Coff_bq = -B_b'*(De*strain_gpt_l*DomegaDk*deps_de_nl_q)*N_q;   
        Stif_bq = Stif_bq + Coff_bq*W(kk)*det(J01)*th; 

        Coff_pa = -(N_p'*B_a);  
        Stif_pa = Stif_pa + Coff_pa*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);

        Coff_pb = -(N_p'*B_b);  
        Stif_pb = Stif_pb + Coff_pb*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);       

        Coff_pp =  N_p'*N_p + B_p'*g_int*c_len*H_bar*B_p + B_p'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_p*N_p + B_p'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl_p*N_p;
        Stif_pp = Stif_pp + Coff_pp*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);              
 
        Coff_pq =  N_p'*N_q + B_p'*g_int*c_len*H_bar*B_q + B_p'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_q*N_q + B_p'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl_q*N_q;       
        Stif_pq = Stif_pq + Coff_pq*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);         

        Coff_qa = -(N_q'*B_a);  
        Stif_qa = Stif_qa + Coff_qa*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);

        Coff_qb = -(N_q'*B_b);  
        Stif_qb = Stif_qb + Coff_qb*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);            

        Coff_qp = N_q'*N_p + B_q'*g_int*c_len*H_bar*B_p + B_q'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_p*N_p + B_q'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl_p*N_p;
        Stif_qp = Stif_qp + Coff_qp*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);         
      
        Coff_qq = N_q'*N_q + B_q'*g_int*c_len*H_bar*B_q + B_q'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_q*N_q + B_q'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl_q*N_q;    
        Stif_qq = Stif_qq + Coff_qq*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);  
        
        fi_gpt_a = fi_gpt_a - (B_a'*stress_gpt)*W(kk)*det(J01)*th;
        fi_gpt_b = fi_gpt_b - (B_b'*stress_gpt)*W(kk)*det(J01)*th; 
        
        fstrain_gpt_p_temp = N_p'*(strain_gpt_nl_p + strain_gpt_nl_q - strain_gpt_l) + B_p'*g_int*c_len*(H_bar*del_strain_gpt_nl_p + H_bar*del_strain_gpt_nl_q);
        fstrain_gpt_q_temp = N_q'*(strain_gpt_nl_p + strain_gpt_nl_q - strain_gpt_l) + B_q'*g_int*c_len*(H_bar*del_strain_gpt_nl_p + H_bar*del_strain_gpt_nl_q);

        fstrain_gpt_p = fstrain_gpt_p - fstrain_gpt_p_temp*W(kk)*det(J01)*th;
        fstrain_gpt_q = fstrain_gpt_q - fstrain_gpt_q_temp*W(kk)*det(J01)*th;
   
        end                  % end of looping on GPs               
 
    else
        
        order = 2;
        [W,Q] = quadrature(order,'GAUSS',2);

        for kk = 1 : size(W,1) 
            
        gpnt = gpnt + 1;
        
        if (ismember(iel,stiff_elements))     % split element  
            kappa0_gpt = kappa0_stiff_m;
%             kappa0_gpt = kappa0_gpt_m;  
            De = De2;
        else
            kappa0_gpt = kappa0_gpt_m;  
            De = De1;
        end
        
        
        e_tilde1 = kappa(iel,kk); % Non-equivalent strain     
        pt = Q(kk,:);   % Quadrature point 

        
        [N, N_a, B_a, J01] = xfemBmatrix1(pt,elemType1,iel,node1,element1); % B matrix and Jacobian for displacement vector         
        [N_p, B_p] = xfemBmatrix2(pt,elemType2,iel,node2,element2); % Shape Function
%         [N_b, B_b] = xfemBmatrix3_normelem(pt,elemType1,iel,node1,element1,xCr_tot,enrich_node); 
%         [N_q, B_q] = xfemBmatrix4_normelem(pt,elemType2,iel,node2,element2,xCr_tot,enrich_node);   

        N_b = zeros(2,8);
        B_b = zeros(3,8);
        N_q = zeros(3,12);
        B_q = zeros(6,12);
        
        gpt_locn = N'*node1(sctr,:);

        strain_gpt_l_a = B_a*u_l_node_a; % Computing Strain at Gaussian Point
        strain_gpt_l_b = B_b*u_l_node_b; % Computing Strain at Gaussian Point
        strain_gpt_nl_p = N_p*strain_nl_node_p; % Computing Non-local Strain vector at Quadrature point
        strain_gpt_nl_q = N_q*strain_nl_node_q; % Computing Additional Non-local Strain vector at Quadrature point
        del_strain_gpt_nl_p = B_p*strain_nl_node_p; % Computing gradient of Non-local Strain vector at Quadrature point
        del_strain_gpt_nl_q = B_q*strain_nl_node_q; % Computing gradient of Non-local Strain vector at Quadrature point

        strain_gpt_l = strain_gpt_l_a + strain_gpt_l_b; % Local Strain Vector
        strain_gpt_nl = strain_gpt_nl_p + strain_gpt_nl_q; % Nonlocal Strain Vector
 
        if (strcmp(eqstrain_def,'VONMISES'))

        [eps_nl, deps_de_nl] = Eq_Strain_VonMises(strain_gpt_nl, nu, K, stressState);  
        [eps_nl_p , deps_de_nl_p] = Eq_Strain_VonMises(strain_gpt_nl_p, nu, K, stressState); 
        [eps_nl_q , deps_de_nl_q] = Eq_Strain_VonMises(strain_gpt_nl_q, nu, K, stressState); 
        
        elseif (strcmp(eqstrain_def,'MAZARS'))

        [eps_nl, deps_de_nl] = Eq_Strain_Mazars_Def(strain_gpt_nl, nu);        

        end
        
%         kappa_gpt = e_tilde1;
        
        f = eps_nl - e_tilde1; % Damage Loading Function

        if f >= 0
            kappa_gpt = eps_nl;
        else
            kappa_gpt = e_tilde1;
        end

        
        if (strcmp(damage_evol_def,'EXPONENTIAL'))

        % Exponential Cohesive Law i.e Damage Evolution Law         
        Omega = compute_damage_exp(kappa_gpt,kappa0_gpt,alpha,beta);
        
        % Coefficient Omega
        if kappa_gpt < kappa0_gpt            
            DomegaDk = 0;  
        elseif e_tilde1 < eps_nl
            DomegaDk = (kappa0_gpt*(alpha*exp(beta*(kappa0_gpt - kappa_gpt)) - alpha + 1))/kappa_gpt^2 + (alpha*beta*kappa0_gpt*exp(beta*(kappa0_gpt - kappa_gpt)))/kappa_gpt;  
        else
            DomegaDk = 0;
        end       
        
        elseif (strcmp(damage_evol_def,'LINEAR'))

        % Linear Damage Evolution Law         
        [Omega] = compute_damage_exp1(kappa_gpt,kappa0_gpt,kappa_crt);      
        
        % Coefficient Omega
        if kappa_gpt < kappa0_gpt            
            DomegaDk = 0;  
        
        elseif e_tilde1 < eps_nl
            DomegaDk = (alpha*(kappa0_gpt/kappa_gpt)^beta*((kappa_crt - kappa_gpt)/(kappa_crt - kappa0_gpt))^(alpha - 1))/(kappa_crt - kappa0_gpt) + (beta*kappa0_gpt*(kappa0_gpt/kappa_gpt)^(beta - 1)*((kappa_crt - kappa_gpt)/(kappa_crt - kappa0_gpt))^alpha)/kappa_gpt^2;        
        else
            DomegaDk = 0;
        end 

        elseif (strcmp(damage_evol_def,'EXPONENTIAL1'))

        % Linear Damage Evolution Law         
        Omega = compute_damage_exp1(kappa_gpt,kappa0_gpt,kappa_crt); % Critical damage      
        
        % Coefficient Omega
        if kappa_gpt < kappa0_gpt            
            DomegaDk = 0;         
        elseif e_tilde1 < eps_nl
            DomegaDk = (kappa0_gpt*exp((kappa0_gpt - kappa_gpt)/(kappa_crt - kappa0_gpt)))/kappa_gpt^2 + (kappa0_gpt*exp((kappa0_gpt - kappa_gpt)/(kappa_crt - kappa0_gpt)))/(kappa_gpt*(kappa_crt - kappa0_gpt));        
        else
            DomegaDk = 0;
        end                
        end 
        
        %------------------Constitutive Relations---------------------%
        sm_stress_gpt = De*strain_gpt_nl_p; % Smooth Stress Vector
%         sm_stress_gpt = (1-Omega)*De*strain_gpt_nl;
        
        if sm_stress_gpt== zeros(3,1)
            sm_stress_gpt(1,1) = tol;
            sm_stress_gpt(2,1) = tol;
            sm_stress_gpt(3,1) = tol;
        end

        sigxx = sm_stress_gpt(1,1);  sigyy = sm_stress_gpt(2,1); sigxy = sm_stress_gpt(3,1);                         
        [sigma1, sigma2, theta] = Compute_Principal_Stress(sm_stress_gpt);
        [g_int, dgdomega] = interaction_function(eta,Omega,R); % Computing Interaction Function    
        
        c_len = (len_par^2);

        if (sigma1^2)>(sigma2^2)     
            den = (sigma1^2);         
            c11 = (sigxx^2 + sigxy^2); c22 = (sigyy^2 + sigxy^2);  c12 = (sigxy*(sigxx + sigyy));
            H_bar1 = [c11 c12; 
                      c12 c22]/den;              
            H_bar = [H_bar1 zeros(2,4);
                    zeros(2,2) H_bar1  zeros(2,2);
                    zeros(2,4) H_bar1];
        elseif (sigma2^2)>(sigma1^2)      
            den = (sigma2^2);
            c11 = (sigxx^2 + sigxy^2); c22 = (sigyy^2 + sigxy^2); c12 = (sigxy*(sigxx + sigyy));    
            H_bar1 = [c11 c12;
                      c12 c22]/den; 
            H_bar =  [H_bar1 zeros(2,4);
                     zeros(2,2) H_bar1  zeros(2,2);
                     zeros(2,4) H_bar1];      
        end

        stress_gpt_a = (1-Omega)*De*strain_gpt_l_a;  % Stress corresponding to strain           
        stress_gpt_b = (1-Omega)*De*strain_gpt_l_b;  % Stress corresponding to strain   
        stress_gpt = stress_gpt_a  +  stress_gpt_b;


        % Computing Stiffness Matrices  

        Coff_aa = B_a'*((1-Omega)*De)*B_a;            
        Stif_aa = Stif_aa + Coff_aa*W(kk)*det(J01)*th;     

        Coff_ab = B_a'*((1-Omega)*De)*B_b;            
        Stif_ab = Stif_ab + Coff_ab*W(kk)*det(J01)*th;      

        Coff_ap = -B_a'*(De*strain_gpt_l*DomegaDk*deps_de_nl_p)*N_p;     
        Stif_ap = Stif_ap + Coff_ap*W(kk)*det(J01)*th;       

        Coff_aq = -B_a'*(De*strain_gpt_l*DomegaDk*deps_de_nl_q)*N_q;  
        Stif_aq = Stif_aq + Coff_aq*W(kk)*det(J01)*th;         

        Coff_ba = B_b'*((1-Omega)*De)*B_a;            
        Stif_ba = Stif_ba + Coff_ba*W(kk)*det(J01)*th;  

        Coff_bb = B_b'*((1-Omega)*De)*B_b;            
        Stif_bb = Stif_bb + Coff_bb*W(kk)*det(J01)*th;   

        Coff_bp = -B_b'*(De*strain_gpt_l*DomegaDk*deps_de_nl_p)*N_p;            
        Stif_bp = Stif_bp + Coff_bp*W(kk)*det(J01)*th; 

        Coff_bq = -B_b'*(De*strain_gpt_l*DomegaDk*deps_de_nl_q)*N_q;   
        Stif_bq = Stif_bq + Coff_bq*W(kk)*det(J01)*th; 

        Coff_pa = -(N_p'*B_a);  
        Stif_pa = Stif_pa + Coff_pa*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);

        Coff_pb = -(N_p'*B_b);  
        Stif_pb = Stif_pb + Coff_pb*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);       

        Coff_pp =  N_p'*N_p + B_p'*g_int*c_len*H_bar*B_p + B_p'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_p*N_p + B_p'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl_p*N_p;
        Stif_pp = Stif_pp + Coff_pp*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);              
 
        Coff_pq =  N_p'*N_q + B_p'*g_int*c_len*H_bar*B_q + B_p'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_q*N_q + B_p'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl_q*N_q;       
        Stif_pq = Stif_pq + Coff_pq*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);          

        Coff_qa = -(N_q'*B_a);  
        Stif_qa = Stif_qa + Coff_qa*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);

        Coff_qb = -(N_q'*B_b);  
        Stif_qb = Stif_qb + Coff_qb*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);            

        Coff_qp = N_q'*N_p + B_q'*g_int*c_len*H_bar*B_p + B_q'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_p*N_p + B_q'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl_p*N_p;
        Stif_qp = Stif_qp + Coff_qp*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);         
       
        Coff_qq = N_q'*N_q + B_q'*g_int*c_len*H_bar*B_q + B_q'*c_len*H_bar*del_strain_gpt_nl_p*dgdomega*DomegaDk*deps_de_nl_q*N_q + B_q'*c_len*H_bar*del_strain_gpt_nl_q*dgdomega*DomegaDk*deps_de_nl_q*N_q;    
        Stif_qq = Stif_qq + Coff_qq*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);         

        fi_gpt_a = fi_gpt_a - (B_a'*stress_gpt)*W(kk)*det(J01)*th;
        fi_gpt_b = fi_gpt_b - (B_b'*stress_gpt)*W(kk)*det(J01)*th; 

        fstrain_gpt_p_temp = N_p'*(strain_gpt_nl_p + strain_gpt_nl_q - strain_gpt_l) + B_p'*g_int*c_len*(H_bar*del_strain_gpt_nl_p + H_bar*del_strain_gpt_nl_q);
        fstrain_gpt_q_temp = N_q'*(strain_gpt_nl_p + strain_gpt_nl_q - strain_gpt_l) + B_q'*g_int*c_len*(H_bar*del_strain_gpt_nl_p + H_bar*del_strain_gpt_nl_q);

        fstrain_gpt_p = fstrain_gpt_p - fstrain_gpt_p_temp*W(kk)*det(J01)*th;
        fstrain_gpt_q = fstrain_gpt_q - fstrain_gpt_q_temp*W(kk)*det(J01)*th;
        
        kappa(iel,kk) = kappa_gpt;     
        end                  % end of looping on GPs   
        
    end  % end of IF STATEMENT  
 
    
    stif_temp = [Stif_aa Stif_ab Stif_ap Stif_aq; 
                 Stif_ba Stif_bb Stif_bp Stif_bq; 
                 Stif_pa Stif_pb Stif_pp Stif_pq; 
                 Stif_qa Stif_qb Stif_qp Stif_qq];
    
    aa = [sctr_a_g sctr_b_g sctr_p_g sctr_q_g];
    bb = [sctr_a_g sctr_b_g sctr_p_g sctr_q_g];

    if ismember(iel,tip_elements)
        [zero_add_disp_dof] = FIND_ADD_DOF(iel,element1,aa,tip_edge_nodes);
        total_zero_add_disp_dof = [total_zero_add_disp_dof; zero_add_disp_dof];
    end    
    
    for ti = 1:40
        for tj = 1:40
            index = index + 1;
            I(index) =  aa(ti);
            J(index) =  bb(tj);
            S(index) = stif_temp(ti,tj);
        end
    end

    fi_a(sctr_a_l',1) = fi_a(sctr_a_l',1) + fi_gpt_a;
    fi_b(sctr_b_l',1) = fi_b(sctr_b_l',1) + fi_gpt_b;
    fstrain_p(sctr_p_l',1) = fstrain_p(sctr_p_l',1) + fstrain_gpt_p;
    fstrain_q(sctr_q_l',1) = fstrain_q(sctr_q_l',1) + fstrain_gpt_q;
    clear fi_gpt_a; clear fi_gpt_b; clear fstrain_gpt_p; clear fstrain_gpt_q; 

end % end of looping on elements

tot_add_dof = unique(add_dof);
split_node_dof = unique(boundary_condition_nodes); 
inactive_node_dof = setdiff(tot_add_dof,split_node_dof');
inactive_node_dof = [inactive_node_dof; fixed_dof_x';fixed_dof_y'; total_zero_add_disp_dof];
active_dof = setdiff(total_dof,inactive_node_dof);

Stif = sparse(I,J,S,total_unknown,total_unknown);
Rint = -[fi_a; fi_b; fstrain_p; fstrain_q];
Rext = lambda*Q_ext;
R = Rext - Rint;
Kres_k = Stif;

end

function [tot_add_dof] = FIND_ADD_DOF(tip_elem,element,total_dof,tip_nodes)

sctr = element(tip_elem,:);
n = size(sctr,2);
tot_add_dof = [];

for i = 1:n   
    
    add_dof = zeros(5,1);
    
 if ismember(sctr(i),tip_nodes)
     add_dof(1) = total_dof(8 + 2*i - 1);
     add_dof(2) = total_dof(8 + 2*i);
     add_dof(3) = total_dof(28 + 3*i - 2);
     add_dof(4) = total_dof(28 + 3*i - 1);
     add_dof(5) = total_dof(28 + 3*i);
     tot_add_dof = [tot_add_dof; add_dof];
 end
 
end %end iedge loop

end

function sctrB = assembly_nonlocal(sctr,total_disp_local, add_disp)

nn   = length(sctr); % Number of nodes
sctr_n = zeros(1,nn);

for i = 1:nn
a = sctr(i);    
b = a + total_disp_local + add_disp;
sctr_n(i) = b + a*2;
end

sctr_nonlocal = zeros(1,12);

cnt = 0 ;

for k = 1 : nn
    cnt = cnt + 1 ;
    sctr_nonlocal(cnt) = sctr_n(k) - 2;

    cnt = cnt + 1 ;
    sctr_nonlocal(cnt) = sctr_n(k) - 1;
    
    cnt = cnt + 1 ;
    sctr_nonlocal(cnt) = sctr_n(k);
end

sctrB = sctr_nonlocal;

end


function sctrB = assembly(e,element1)

sctr = element1(e,:);
nn   = length(sctr);

for k = 1 : nn
    sctrBfem(2*k-1) = 2*sctr(k)-1;
    sctrBfem(2*k)   = 2*sctr(k);
end
    sctrB = sctrBfem;
end % End of Assembly

function [Omega] = compute_damage_exp(kappa_gpt,kappa0_gpt,alpha,beta)
 
    if kappa_gpt < kappa0_gpt
        
        Omega = 0;
        
    else 
        
        a = (kappa0_gpt/kappa_gpt);
        c = beta*(kappa_gpt - kappa0_gpt);
        temp = (1-alpha) + alpha*exp(-c);
        Omega = 1 - a*temp;

    end
    
end % END OF FUNCTION compute_damage


function [Omega] = compute_damage_linear(kappa_gpt,kappa0_gpt,kappa_crt,alpha,beta)
    
    if kappa_gpt < kappa0_gpt
        
        Omega = 0;
 
    elseif  (kappa0_gpt <= kappa_gpt) && (kappa_gpt < kappa_crt)
        
        a = ((kappa_crt - kappa_gpt)/(kappa_crt - kappa0_gpt))^alpha;
        b = (kappa0_gpt/kappa_gpt)^beta;
        Omega = 1 - (b*a); 
    
    elseif  kappa_gpt >= kappa_crt
        
        Omega = 0.9999999999999;  

    end
    
end % END OF FUNCTION compute_damage

function [g,dgdomega] = interaction_function(eta,omega,R)

    num = (1-R)*exp(-eta*omega) + R - exp(-eta);
    den = 1 - exp(-eta);
    g = num/den;
    num1 = (R-1)*eta*exp(-eta*omega);
    dgdomega = num1/den;
    
%       num = exp(-eta*omega) - exp(-eta);
%       den = 1 - exp(-eta);
%       g = num/den;
%       dgdomega = (eta*exp(-eta*omega))/(exp(-eta) - 1);
%     g = exp(-eta*omega);
%     dgdomega = -eta*exp(-eta*omega);
    
end % END OF FUNCTION interaction_function


function [sig1, sig2, alpha] = Compute_Principal_Stress(stress_gpt)
    sigxx = stress_gpt(1,1);
    sigyy = stress_gpt(2,1);
    sigxy = stress_gpt(3,1);
    a = (sigxx + sigyy)/2;
    b = (sigxx - sigyy)/2;
    sig1 = a + sqrt((b^2) + (sigxy^2));
    sig2 = a - sqrt((b^2) + (sigxy^2));
    den = (sigxx - sigyy);
    if den==0
        alpha = 90;
    else
        p = (2*sigxy)/den;
        alpha = 0.5*atand(p);
    end
end


function [N, N_l, B,J0] = xfemBmatrix1(pt,elemType,e,node1,element1)

sctr = element1(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
J0 = node1(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
Gpt = N' * node1(sctr,:);                  % GP in global coord, used

N_l(1,1:2:8) = N(1,:); 
N_l(2,2:2:8) = N(1,:);

% Bfem is always computed
Bfem = zeros(3,2*nn);
Bfem(1,1:2:2*nn)  = dNdx(:,1)' ;
Bfem(2,2:2:2*nn)  = dNdx(:,2)' ;
Bfem(3,1:2:2*nn)  = (dNdx(:,2))' ;
Bfem(3,2:2:2*nn)  = (dNdx(:,1))' ;
B = Bfem;
end              % end of switch 

function [N_nl,B] = xfemBmatrix2(pt,elemType,e,node2,element2)

sctr = element2(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
J0 = node2(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY

N_nl = zeros(3,3*nn);
N_nl(1,1:3:3*nn) = N(:,1)';
N_nl(2,2:3:3*nn) = N(:,1)';
N_nl(3,3:3:3*nn) = N(:,1)';

% Bfem is always computed
Bfem = zeros(6,3*nn);
Bfem(1,1:3:3*nn)  = dNdx(:,1)' ;
Bfem(2,1:3:3*nn)  = dNdx(:,2)' ;
Bfem(3,2:3:3*nn)  = dNdx(:,1)' ;
Bfem(4,2:3:3*nn)  = dNdx(:,2)' ;
Bfem(5,3:3:3*nn)  = dNdx(:,1)' ;
Bfem(6,3:3:3*nn)  = dNdx(:,2)' ;
B = Bfem;
end            


function [N_la, B_la] = xfemBmatrix3(pt,elemType,e,node1,element1,xCohSeg,enrich_node)
sctr = element1(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
J0 = node1(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
Gpt = N' * node1(sctr,:);                  % GP in global coord, used
Bfem = zeros(3,2*nn);
Nfem = zeros(2,2*nn);

% Switch between non-enriched and enriched elements
if (any(enrich_node(sctr)) == 0) % Non-enriched elements
    B_la = Bfem;
    N_la = Nfem;
else                               % Enriched elements
    Bxfem = [];
    Nenr = [];
    % loop on nodes, check node is enriched ...
    for in = 1 : nn
        if (enrich_node(sctr(in)) == 1)     % H(x) enriched node
        % Enrichment function, H(x) at global Gauss point
        dist = signed_distance(xCohSeg,Gpt);
        Hgp  = heaviside(dist);
        % Enrichment function, H(x) at node "in"
        dist = signed_distance(xCohSeg,node1(sctr(in),:));
        Hi   = heaviside(dist);
        % Bxfem at node "in"
        BI_enr = [dNdx(in,1)*(Hgp - Hi) 0 ;
                    0 dNdx(in,2)*(Hgp - Hi) ;
                    dNdx(in,2)*(Hgp - Hi) dNdx(in,1)*(Hgp - Hi)];

        Ntemp = [N(in,1)*(Hgp - Hi) 0;
                 0 N(in,1)*(Hgp - Hi)];
        else
        BI_enr = zeros(3,2);
        Ntemp = zeros(2,2);
        end
        Nenr = [Nenr Ntemp]; % Add to the total Bxfem
        Bxfem = [Bxfem BI_enr];
        clear Ntemp; clear BI_enr;   
    end % B matrix
B_la = Bxfem;
N_la = Nenr;    
end          % end of loop on nodes
end  


function [N2, B2] = xfemBmatrix4(pt,elemType,e,node2,element2,xCohSeg,enrich_node)

sctr = element2(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
Gpt = N' * node2(sctr,:);                  % GP in global coord, used
J0 = node2(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
Nenr = [];
Bxfem = [];

for in = 1 : nn
        if (enrich_node(sctr(in)) == 1)     % H(x) enriched node
        % Enrichment function, H(x) at global Gauss point
        dist1 = signed_distance(xCohSeg,Gpt);
        Hgp  = heaviside(dist1);
        % Enrichment function, H(x) at node "in"
        dist2 = signed_distance(xCohSeg,node2(sctr(in),:));
        Hi   = heaviside(dist2);
        
        % Bxfem at node "in"      
        Ntemp = [N(in,1)*(Hgp - Hi) 0 0;
                 0 N(in,1)*(Hgp - Hi) 0;
                 0 0 N(in,1)*(Hgp - Hi)];
        
        BI_enr = [dNdx(in,1)*(Hgp - Hi) 0 0;
                  dNdx(in,2)*(Hgp - Hi) 0 0;
                    0 dNdx(in,1)*(Hgp - Hi) 0;
                    0 dNdx(in,2)*(Hgp - Hi) 0;  
                    0 0 dNdx(in,1)*(Hgp - Hi);
                    0 0 dNdx(in,2)*(Hgp - Hi)];
        else
        Ntemp = zeros(3,3);
        BI_enr = zeros(6,3); 
        end
                 
        Nenr = [Nenr Ntemp]; % Add to the total Bxfem
        Bxfem = [Bxfem BI_enr];
        
end          % end of loop on nodes
% B matrix
N2 = Nenr;
B2 = Bxfem;
end    


function [N_la, B_la] = xfemBmatrix3_normelem(pt,elemType,e,node1,element1,xCr_tot,enrich_node)
sctr = element1(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
J0 = node1(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
Gpt = N' * node1(sctr,:);                  % GP in global coord, used
Bxfem = [];
Nenr = [];


for in = 1 : nn
        
        if (enrich_node(sctr(in)) == 1)     % H(x) enriched node
        % Enrichment function, H(x) at global Gauss point
        
        xCohSeg = xCr_tot;      
        
        dist = signed_distance(xCohSeg,Gpt);
        Hgp  = heaviside(dist);
        % Enrichment function, H(x) at node "in"
        dist = signed_distance(xCohSeg,node1(sctr(in),:));
        Hi   = heaviside(dist);
        % Bxfem at node "in"
        BI_enr = [dNdx(in,1)*(Hgp - Hi) 0 ;
                    0 dNdx(in,2)*(Hgp - Hi) ;
                    dNdx(in,2)*(Hgp - Hi) dNdx(in,1)*(Hgp - Hi)];

        Ntemp = [N(in,1)*(Hgp - Hi) 0;
                 0 N(in,1)*(Hgp - Hi)];
        else
        BI_enr = zeros(3,2);
        Ntemp = zeros(2,2);
        end
        Nenr = [Nenr Ntemp]; % Add to the total Bxfem
        Bxfem = [Bxfem BI_enr];
        clear Ntemp; clear BI_enr;   
end % B matrix
    
B_la = Bxfem;
N_la = Nenr;    
end  


function [N2, B2] = xfemBmatrix4_normelem(pt,elemType,e,node2,element2,xCr_tot,enrich_node)

sctr = element2(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
Gpt = N' * node2(sctr,:);                  % GP in global coord, used
J0 = node2(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
Nenr = [];
Bxfem = [];

for in = 1 : nn
        if (enrich_node(sctr(in)) == 1)     % H(x) enriched node
        % Enrichment function, H(x) at global Gauss point
        
        xCohSeg = xCr_tot;

        dist1 = signed_distance(xCohSeg,Gpt);
        Hgp  = heaviside(dist1);
        % Enrichment function, H(x) at node "in"
        dist2 = signed_distance(xCohSeg,node2(sctr(in),:));
        Hi   = heaviside(dist2);
        
        % Bxfem at node "in"      
        Ntemp = [N(in,1)*(Hgp - Hi) 0 0;
                 0 N(in,1)*(Hgp - Hi) 0;
                 0 0 N(in,1)*(Hgp - Hi)];
        
        BI_enr = [dNdx(in,1)*(Hgp - Hi) 0 0;
                  dNdx(in,2)*(Hgp - Hi) 0 0;
                    0 dNdx(in,1)*(Hgp - Hi) 0;
                    0 dNdx(in,2)*(Hgp - Hi) 0;  
                    0 0 dNdx(in,1)*(Hgp - Hi);
                    0 0 dNdx(in,2)*(Hgp - Hi)];
        else
        Ntemp = zeros(3,3);
        BI_enr = zeros(6,3); 
        end
                 
        Nenr = [Nenr Ntemp]; % Add to the total Bxfem
        Bxfem = [Bxfem BI_enr];
        
end          % end of loop on nodes
% B matrix
N2 = Nenr;
B2 = Bxfem;
end    

function d = signed_distance(xCohSeg,pt)
% Compute the signed distance from point x to crack xCr
% Inputs:
%     - xCr(2,2) : coordinates of points defining the crack
%     - pt(1,2)   : coordinate of point
s=size(xCohSeg,1);
for k=1:s-1
    
x0  = xCohSeg(k,1); y0 = xCohSeg(k,2);
x1  = xCohSeg(k+1,1); y1 = xCohSeg(k+1,2);
x   = pt(1,1);
y   = pt(1,2);
if k==s-1
    c=x;
else
    c=x1;
end
if (x<=c) %&& (x<=c)
l   = sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)) ;
phi = (y0-y1)*x + (x1-x0)*y + (x0*y1-x1*y0) ;
d  = phi/l;

end
end
end

function [W,Q] = quadrature( quadorder, qt, sdim )

    if ( nargin < 3 )   % set default arguments
        if ( strcmp(qt,'GAUSS') == 1 )
            dim = 1;
        else
            dim = 2;
        end
    end

if ( nargin < 2 )
    type = 'GAUSS';
end

if ( strcmp(qt,'GAUSS') == 1 )

    if ( quadorder > 8 )  % check for valid quadrature order
        disp('Order of quadrature too high for Gaussian Quadrature');
        quadorder =8;
    end

    quadpoint=zeros(quadorder^sdim ,sdim);
    quadweight=zeros(quadorder^sdim,1);

    r1pt=zeros(quadorder,1); r1wt=zeros(quadorder,1);

    switch ( quadorder )
        case 1
            r1pt(1) = 0.000000000000000;
            r1wt(1) = 2.000000000000000;

        case 2
            r1pt(1) = 0.577350269189626;
            r1pt(2) =-0.577350269189626;

            r1wt(1) = 1.000000000000000;
            r1wt(2) = 1.000000000000000;

        case 3
            r1pt(1) = 0.774596669241483;
            r1pt(2) =-0.774596669241483;
            r1pt(3) = 0.000000000000000;

            r1wt(1) = 0.555555555555556;
            r1wt(2) = 0.555555555555556;
            r1wt(3) = 0.888888888888889;

        case 4
            r1pt(1) = 0.861134311594053;
            r1pt(2) =-0.861134311594053;
            r1pt(3) = 0.339981043584856;
            r1pt(4) =-0.339981043584856;

            r1wt(1) = 0.347854845137454;
            r1wt(2) = 0.347854845137454;
            r1wt(3) = 0.652145154862546;
            r1wt(4) = 0.652145154862546;

        case 5
            r1pt(1) = 0.906179845938664;
            r1pt(2) =-0.906179845938664;
            r1pt(3) = 0.538469310105683;
            r1pt(4) =-0.538469310105683;
            r1pt(5) = 0.000000000000000;

            r1wt(1) = 0.236926885056189;
            r1wt(2) = 0.236926885056189;
            r1wt(3) = 0.478628670499366;
            r1wt(4) = 0.478628670499366;
            r1wt(5) = 0.568888888888889;

        case 6
            r1pt(1) = 0.932469514203152;
            r1pt(2) =-0.932469514203152;
            r1pt(3) = 0.661209386466265;
            r1pt(4) =-0.661209386466265;
            r1pt(5) = 0.238619186003152;
            r1pt(6) =-0.238619186003152;

            r1wt(1) = 0.171324492379170;
            r1wt(2) = 0.171324492379170;
            r1wt(3) = 0.360761573048139;
            r1wt(4) = 0.360761573048139;
            r1wt(5) = 0.467913934572691;
            r1wt(6) = 0.467913934572691;

        case 7
            r1pt(1) =  0.949107912342759;
            r1pt(2) = -0.949107912342759;
            r1pt(3) =  0.741531185599394;
            r1pt(4) = -0.741531185599394;
            r1pt(5) =  0.405845151377397;
            r1pt(6) = -0.405845151377397;
            r1pt(7) =  0.000000000000000;

            r1wt(1) = 0.129484966168870;
            r1wt(2) = 0.129484966168870;
            r1wt(3) = 0.279705391489277;
            r1wt(4) = 0.279705391489277;
            r1wt(5) = 0.381830050505119;
            r1wt(6) = 0.381830050505119;
            r1wt(7) = 0.417959183673469;

        case 8
            r1pt(1) =  0.960289856497536;
            r1pt(2) = -0.960289856497536;
            r1pt(3) =  0.796666477413627;
            r1pt(4) = -0.796666477413627;
            r1pt(5) =  0.525532409916329;
            r1pt(6) = -0.525532409916329;
            r1pt(7) =  0.183434642495650;
            r1pt(8) = -0.183434642495650;

            r1wt(1) = 0.101228536290376;
            r1wt(2) = 0.101228536290376;
            r1wt(3) = 0.222381034453374;
            r1wt(4) = 0.222381034453374;
            r1wt(5) = 0.313706645877887;
            r1wt(6) = 0.313706645877887;
            r1wt(7) = 0.362683783378362;
            r1wt(8) = 0.362683783378362;

        otherwise
            disp('Order of quadrature to high for Gaussian Quadrature');

    end  % end of quadorder switch

    n=1;

    if ( sdim == 1 )
        for i = 1:quadorder
            quadpoint(n,:) = [ r1pt(i) ];
            quadweight(n) = r1wt(i);
            n = n+1;
        end

    elseif ( sdim == 2 )
        for i = 1:quadorder
            for j = 1:quadorder
                quadpoint(n,:) = [ r1pt(i), r1pt(j)];
                quadweight(n) = r1wt(i)*r1wt(j);
                n = n+1;
            end
        end

    else % sdim == 3
        for i = 1:quadorder
            for j = 1:quadorder
                for k = 1:quadorder
                    quadpoint(n,:) = [ r1pt(i), r1pt(j), r1pt(k) ];
                    quadweight(n) = r1wt(i)*r1wt(j)*r1wt(k);
                    n = n+1;
                end
            end
        end

    end

    Q=quadpoint;
    W=quadweight;
    % END OF GAUSSIAN QUADRATURE DEFINITION

elseif ( strcmp(qt,'TRIANGULAR') == 1 )

    if ( sdim == 3 )  %%% TETRAHEDRA

        if ( quadorder ~= 1 &  quadorder ~= 2 &  quadorder ~= 3  )
            % check for valid quadrature order
            disp('Incorect quadrature order for triangular quadrature');
            quadorder = 1;
        end

        if  ( quadorder == 1 )
            quadpoint = [ 0.25 0.25 0.25 ];
            quadweight = 1;

        elseif ( quadorder == 2 )
            quadpoint = [ 0.58541020  0.13819660  0.13819660;
                0.13819660  0.58541020  0.13819660;
                0.13819660  0.13819660  0.58541020;
                0.13819660  0.13819660  0.13819660];
            quadweight = [1; 1; 1; 1]/4;

        elseif ( quadorder == 3 )
            quadpoint = [ 0.25  0.25  0.25;
                1/2   1/6   1/6;
                1/6   1/2   1/6;
                1/6   1/6   1/2;
                1/6   1/6   1/6];
            quadweight = [-4/5 9/20 9/20 9/20 9/20]';

        end

        Q=quadpoint;
        W=quadweight/6;

    else  %%% TRIANGLES

        if ( quadorder > 7 ) % check for valid quadrature order
            disp('Quadrature order too high for triangular quadrature');
            quadorder = 1;
        end

        if ( quadorder == 1 )   % set quad points and quadweights
            quadpoint = [ 0.3333333333333, 0.3333333333333 ];
            quadweight = 1;

        elseif ( quadorder == 2 )
            quadpoint = zeros( 3, 2 );
            quadweight = zeros( 3, 1 );

            quadpoint(1,:) = [ 0.1666666666667, 0.1666666666667 ];
            quadpoint(2,:) = [ 0.6666666666667, 0.1666666666667 ];
            quadpoint(3,:) = [ 0.1666666666667, 0.6666666666667 ];

            quadweight(1) = 0.3333333333333;
            quadweight(2) = 0.3333333333333;
            quadweight(3) = 0.3333333333333;

        elseif ( quadorder <= 5 )
            quadpoint = zeros( 7, 2 );
            quadweight = zeros( 7, 1 );

            quadpoint(1,:) = [ 0.1012865073235, 0.1012865073235 ];
            quadpoint(2,:) = [ 0.7974269853531, 0.1012865073235 ];
            quadpoint(3,:) = [ 0.1012865073235, 0.7974269853531 ];
            quadpoint(4,:) = [ 0.4701420641051, 0.0597158717898 ];
            quadpoint(5,:) = [ 0.4701420641051, 0.4701420641051 ];
            quadpoint(6,:) = [ 0.0597158717898, 0.4701420641051 ];
            quadpoint(7,:) = [ 0.3333333333333, 0.3333333333333 ];

            quadweight(1) = 0.1259391805448;
            quadweight(2) = 0.1259391805448;
            quadweight(3) = 0.1259391805448;
            quadweight(4) = 0.1323941527885;
            quadweight(5) = 0.1323941527885;
            quadweight(6) = 0.1323941527885;
            quadweight(7) = 0.2250000000000;

        else
            quadpoint = zeros( 13, 2 );
            quadweight = zeros( 13, 1 );

            quadpoint(1 ,:) = [ 0.0651301029022, 0.0651301029022 ];
            quadpoint(2 ,:) = [ 0.8697397941956, 0.0651301029022 ];
            quadpoint(3 ,:) = [ 0.0651301029022, 0.8697397941956 ];
            quadpoint(4 ,:) = [ 0.3128654960049, 0.0486903154253 ];
            quadpoint(5 ,:) = [ 0.6384441885698, 0.3128654960049 ];
            quadpoint(6 ,:) = [ 0.0486903154253, 0.6384441885698 ];
            quadpoint(7 ,:) = [ 0.6384441885698, 0.0486903154253 ];
            quadpoint(8 ,:) = [ 0.3128654960049, 0.6384441885698 ];
            quadpoint(9 ,:) = [ 0.0486903154253, 0.3128654960049 ];
            quadpoint(10,:) = [ 0.2603459660790, 0.2603459660790 ];
            quadpoint(11,:) = [ 0.4793080678419, 0.2603459660790 ];
            quadpoint(12,:) = [ 0.2603459660790, 0.4793080678419 ];
            quadpoint(13,:) = [ 0.3333333333333, 0.3333333333333 ];

            quadweight(1 ) = 0.0533472356088;
            quadweight(2 ) = 0.0533472356088;
            quadweight(3 ) = 0.0533472356088;
            quadweight(4 ) = 0.0771137608903;
            quadweight(5 ) = 0.0771137608903;
            quadweight(6 ) = 0.0771137608903;
            quadweight(7 ) = 0.0771137608903;
            quadweight(8 ) = 0.0771137608903;
            quadweight(9 ) = 0.0771137608903;
            quadweight(10) = 0.1756152576332;
            quadweight(11) = 0.1756152576332;
            quadweight(12) = 0.1756152576332;
            quadweight(13) =-0.1495700444677;

        end

        Q=quadpoint;
        W=quadweight/2;   % ATTENTION ATTENTION WHY DIVIDE TO 2?????
    end

end  % end of TRIANGULAR initialization
end
% END OF FUNCTION



function [node,element] = meshRegion(pt1, pt2, pt3, pt4, numx, numy, elemType)

switch elemType

    case 'Q4'           % here we generate the mesh of Q4 elements
        nnx=numx+1;
        nny=numy+1;
        node=square_node_array(pt1,pt2,pt3,pt4,nnx,nny);
        inc_u=1;
        inc_v=nnx;
        node_pattern=[ 1 2 nnx+2 nnx+1 ];
        [element]=make_elem(node_pattern,numx,numy,inc_u,inc_v);

    case 'Q8'           % here we generate a mesh of Q9 elements
        nnx=numx+1;
        nny=numy+1;
        node=square_node_array(pt1,pt2,pt3,pt4,nnx,nny);
        inc_u=1;
        inc_v=nnx;
        node_pattern=[ 1 2 nnx+2 nnx+1 ];
        element=make_elem(node_pattern,numx,numy,inc_u,inc_v);
        [element,node]=q4totq8(element,node,numx,numy);

    otherwise
        error('For now, only Q4 and Q9 are supported by the mesh generator');
end

end % END OF FUNCTION meshRegion


function [Nv,dNdxi] = lagrange_basis(type,coord,dim)

    if ( nargin == 2 )
        dim=1;
    end

    switch type   
    case 'L2'
        %%%%%%%%%%%%%%%%%%%%% L2 TWO NODE LINE ELEMENT %%%%%%%%%%%%%%%%%%%%%
        %
        %    1---------2
        %
        if size(coord,2) < 1
            disp('Error coordinate needed for the L2 element')
        else
            xi=coord(1);
            N=([1-xi,1+xi]/2)';
            dNdxi=[-1;1]/2;
        end

    case 'L3'
        %%%%%%%%%%%%%%%%%%% L3 THREE NODE LINE ELEMENT %%%%%%%%%%%%%%%%%%%%%
        %
        %    1---------2----------3
        %
        if size(coord,2) < 1
            disp('Error two coordinates needed for the L3 element')
        else
            xi=coord(1);
            N=[(1-xi)*xi/(-2);(1+xi)*xi/2;1-xi^2];
            dNdxi=[xi-.5;xi+.5;-2*xi];
        end

    case 'T3'
        %%%%%%%%%%%%%%%% T3 THREE NODE TRIANGULAR ELEMENT %%%%%%%%%%%%%%%%%%
        %
        %               3
        %             /  \
        %            /    \
        %           /      \
        %          /        \
        %         /          \
        %        /            \
        %       /              \
        %      /                \
        %     /                  \
        %    1--------------------2
        %
        if size(coord,2) < 2
            disp('Error two coordinates needed for the T3 element')
        else
            xi=coord(1); eta=coord(2);
            N=[1-xi-eta;xi;eta];
            dNdxi=[-1,-1;1,0;0,1];
        end

    case 'T3fs'
        if size(coord,2) < 2
            disp('Error two coordinates needed for the T3fs element')
        else
            xi=coord(1); eta=coord(2);
            N=[1-xi-eta;xi;eta];
            dNdxi=[-1,-1;1,0;0,1];
        end

    case 'T4'
        %%%%%%%%%% T4 FOUR NODE TRIANGULAR CUBIC BUBBLE ELEMENT %%%%%%%%%%%%
        %
        %               3
        %             /  \
        %            /    \
        %           /      \
        %          /        \
        %         /          \
        %        /      4     \
        %       /              \
        %      /                \
        %     /                  \
        %    1--------------------2
        %
        if size(coord,2) < 2
            disp('Error two coordinates needed for the T4 element')
        else
            xi=coord(1); eta=coord(2);
            N=[1-xi-eta-3*xi*eta;xi*(1-3*eta);eta*(1-3*xi);9*xi*eta];
            dNdxi=[-1-3*eta,-1-3*xi;
                1-3*eta, -3*xi;
                -3*eta,   1-3*xi;
                9*eta,   9*xi ];
        end

    case 'T6'
        %%%%%%%%%%%%%%%%%% T6 SIX NODE TRIANGULAR ELEMENT %%%%%%%%%%%%%%%%%%
        %
        %               3
        %             /  \
        %            /    \
        %           /      \
        %          /        \
        %         6          5
        %        /            \
        %       /              \
        %      /                \
        %     /                  \
        %    1---------4----------2
        %
        if size(coord,2) < 2
            disp('Error two coordinates needed for the T6 element')
        else
            xi=coord(1); eta=coord(2);
            N=[1-3*(xi+eta)+4*xi*eta+2*(xi^2+eta^2);
                xi*(2*xi-1);
                eta*(2*eta-1);
                4*xi*(1-xi-eta);
                4*xi*eta;
                4*eta*(1-xi-eta)];

            dNdxi=[4*(xi+eta)-3   4*(xi+eta)-3;
                4*xi-1              0;
                0        4*eta-1;
                4*(1-eta-2*xi)          -4*xi;
                4*eta           4*xi;
                -4*eta  4*(1-xi-2*eta)];
        end
        
        case 'Q4'
            %%%%%%%%%%%%%%% Q4 FOUR NODE QUADRILATERIAL ELEMENT %%%%%%%%%%%%%%%%
            %
            %    4--------------------3
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    1--------------------2
            %
            if size(coord,2) < 2
                disp('Error two coordinates needed for the Q4 element')
            else
                xi=coord(1); eta=coord(2);
                N=1/4*[ (1-xi)*(1-eta);
                    (1+xi)*(1-eta);
                    (1+xi)*(1+eta);
                    (1-xi)*(1+eta)];
                dNdxi=1/4*[-(1-eta), -(1-xi);
                    1-eta,    -(1+xi);
                    1+eta,      1+xi;
                    -(1+eta),   1-xi];
            end
          case 'Q8'
            %%%%%%%%%%%%%%% Q8 FOUR NODE QUADRILATERIAL ELEMENT %%%%%%%%%%%%%%%%
            %
            %    4---------7----------3
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    8                    6
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    1---------5----------2
            %
            if size(coord,2) < 2
            disp('Error two coordinates needed for the Q8 element')
            else
            xi=coord(1); eta=coord(2);
            N=1/4*[-1*(1-xi)*(1-eta)*(1+xi+eta);
                    -1*(1+xi)*(1-eta)*(1-xi+eta);
                    -1*(1+xi)*(1+eta)*(1-xi-eta);
                    -1*(1-xi)*(1+eta)*(1+xi-eta);
                    2*(1-xi^2)*(1-eta);
                    2*(1+xi)*(1-eta^2);
                    2*(1-xi^2)*(1+eta);
                    2*(1-xi)*(1-eta^2)];
            dNdxi=1/4*[(1-eta)*(2*xi+eta),  (1-xi)*(2*eta+xi);
                        (1-eta)*(2*xi-eta), (1+xi)*(2*eta-xi);
                        (1+eta)*(2*xi+eta), (1+xi)*(2*eta+xi);
                        (1+eta)*(2*xi-eta), (1-xi)*(2*eta-xi);
                        -4*xi*(1-eta),      -2*(1-xi^2);
                        2*(1-eta^2),        -4*eta*(1+xi);
                        -4*xi*(1+eta),       2*(1-xi^2);
                        -2*(1-eta^2),       -4*eta*(1-xi)];
            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        otherwise
            disp(['Element ',type,' not yet supported'])
            N=[]; dNdxi=[];
    end

    I=eye(dim);
    Nv=[];
    
        for i=1:size(N,1)
            Nv=[Nv;I*N(i)];
        end

    if ( dim == 1 )
        B=dNdxi;
    elseif ( dim == 2 )
        B=zeros(dim*size(N,1),3);

        B(1:dim:dim*size(N,1)-1,1) = dNdxi(:,1);
        B(2:dim:dim*size(N,1),2)   = dNdxi(:,2);

        B(1:dim:dim*size(N,1)-1,3) = dNdxi(:,2);
        B(2:dim:dim*size(N,1),3)   = dNdxi(:,1);
    elseif ( dim == 3 )
        B=zeros(dim*size(N,1),6);

        disp('Error: need to add 3D N and dNdxi')

        B(1:dim:dim*size(N,1)-2,1) = dNdxi(:,1);
        B(2:dim:dim*size(N,1)-1,2) = dNdxi(:,2);
        B(3:dim:dim*size(N,1),3)   = dNdxi(:,3);

        B(2:dim:dim*size(N,1)-1,4) = dNdxi(:,3);
        B(3:dim:dim*size(N,1),4)   = dNdxi(:,2);

        B(3:dim:dim*size(N,1),5)   = dNdxi(:,1);
        B(1:dim:dim*size(N,1)-2,5) = dNdxi(:,3);

        B(1:dim:dim*size(N,1)-2,6) = dNdxi(:,2);
        B(2:dim:dim*size(N,1)-1,6) = dNdxi(:,1);

    end

end % % END OF FUNCTION lagrange_basis

function [W,Q]=discontQ4quad(order,phi)

        corner = [1 2 3 4 1];
        node   = [-1 -1; 1 -1; 1 1; -1 1];

        % loop on element edges
        for i = 1 : 4
            n1 = corner(i);
            n2 = corner(i+1);
            if ( phi(n1)*phi(n2) < 0 )
                r    = phi(n1)/(phi(n1)-phi(n2));
                pnt  = (1-r)*node(n1,:)+r*node(n2,:);
                node = [node;pnt];
            end
        end

        % get decompused triangles
        tri = delaunay(node(:,1),node(:,2));
        tri = tricheck(node,tri);

        % loop over subtriangles to get quadrature points and weights
        pt = 1;
        for e = 1:size(tri,1)
            [w,q]=quadrature(order,'TRIANGULAR',2);
            % transform quadrature points into the parent element
            coord = node(tri(e,:),:);
            a = det([coord,[1;1;1]])/2;
            if ( a<0 )  % need to swap connectivity
                coord = [coord(2,:);coord(1,:);coord(3,:)];
                a = det([coord,[1;1;1]])/2;
            end

            if ( a~=0 )
                for n=1:length(w)
                    N=lagrange_basis('T3',q(n,:));
                    Q(pt,:) = N'*coord;
                    W(pt,1) = 2*w(n)*a;
                    pt = pt+1;
                end
            end

        end
end


function conn=tricheck(node,conn,verbose)

% FUNCTION
% conn=tricheck(node,conn,verbose)
% This function check wether a triangle has a negative Jacobian, and if
% so reorders it so that the the Jacobian is positive.

    if ( nargin==2 )
        verbose=0;
    end

    if ( size(node,2)==3 )
        node=node(:,1:2);
    end

    count=0;

    for e=1:size(conn,1)

        sctr=conn(e,:);
        [N,dNdxi]=lagrange_basis('T3',[1/3 1/3]);
        detJ=det(node(sctr,:)'*dNdxi);

        if ( detJ < 0 )
            %disp(['NEGATIVE JACOBIAN IN ELEMENT ',num2str(e)])
            conn(e,:)=fliplr(sctr);
            count=count+1;
        elseif ( detJ == 0 )
            disp(['ZERO JACOBIAN IN ELEMENT ',num2str(e),' CANNOT FIX'])
        end
    end

    if ( verbose )
        disp(['TRICHECK FOUND ',num2str(count),' NEGATIVE JACOBIANS, ALL FIXED'])
    end
end


function [Omega] = compute_damage_exp1(kappa_gpt,kappa0_gpt,kappa_crt)

    if kappa_gpt <= kappa0_gpt       
        Omega = 0;       
    else   
        a = (kappa0_gpt/kappa_gpt);
        b = kappa_gpt - kappa0_gpt;
        c = kappa_crt - kappa0_gpt;       
        Omega = 1 - a*exp(-(b/c));
    end
    
end % END OF FUNCTION compute_damage