function [eps_nl, deps_de_nl] = Eq_Strain_VonMises(strain_gpt_nonlocal, nu, k, stressState)
   
    exx_nl = strain_gpt_nonlocal(1,1);
    eyy_nl = strain_gpt_nonlocal(2,1);
    exy_nl = strain_gpt_nonlocal(3,1)/2; 
    eyx_nl = strain_gpt_nonlocal(3,1)/2; 
    tol = 1e-25; % Tolerance
    
    if (strcmp(stressState,'PLANE_STRESS'))
    
    % Computing Nonlocal Equivalent Strain from Nonlocal Strain Vector

    a1 = 1/(2*k);
    a2 = (k-1)/(1 - 2*nu);
    a3 = (2*k)/((1+nu)^2);
    a4 = 1/((1+nu)^2);    
    a5 = (2*nu)/((1-nu)^2); 
    a6 = (1-2*nu)/(1-nu); 
    a7 = 2 + a5;  
    a8 = -1 + a5;   

    H = [a7 a8 0;
           a8 a7 0;
           0 0 1.5];         

    del = a6*[1; 1; 0];  

    I1_nl = a6*(exx_nl+eyy_nl);
    J2_nl = (2*(exx_nl^2) + 2*(eyy_nl^2) - 2*(exx_nl*eyy_nl)) + 3*(exy_nl^2+eyx_nl^2)+ a5*((exx_nl+eyy_nl)^2);    
    AA_nl = (a2*I1_nl)^2 + (a3)*J2_nl;  

    if AA_nl <= 0
        AA_nl = tol;
    end

    eps_nl = a1*(a2*I1_nl + sqrt(AA_nl)); % Computing Nonlocal Equivalent Strain from Strain Vector
    deps_de1 = a1*a2*(1 + a2*(AA_nl^(-0.5))*I1_nl)*del + a4*(AA_nl^(-0.5))*H*strain_gpt_nonlocal;
    deps_de_nl = deps_de1'; % Derivation of Nonlocal Equivalent strain wrt Nonlocal strain vector
                   
    elseif (strcmp(stressState,'PLANE_STRAIN'))
    
    a1 = 1/(2*k);
    a2 = (k-1)/(1-2*nu);
    a3 = (2*k)/((1+nu)^2);
    a4 = 1/((1+nu)^2);  
    del = [1; 1; 0];

    H = [2 -1 0; 
        -1 2 0; 
         0 0 1.5];
     
    I1_nl = exx_nl + eyy_nl;
    J2_nl = (2*(exx_nl^2) + 2*(eyy_nl^2) - 2*(exx_nl*eyy_nl)) + 3*(exy_nl^2+eyx_nl^2);   
    AA_nl = (a2*I1_nl)^2 + (a3)*J2_nl;

    if AA_nl <=0
        AA_nl = tol;
    end

    eps_nl = a1*(a2*I1_nl + sqrt(AA_nl)); % Computing Nonlocal equivalent Strain from Strain Vector
    deps_de1 = a1*a2*(1 + a2*(AA_nl^(-0.5))*I1_nl)*del + a4*(AA_nl^(-0.5))*H*strain_gpt_nonlocal;
    deps_de_nl = deps_de1'; % Derivation of Nonlocal Equivalent strain wrt Nonlocal strain vector
    end

end