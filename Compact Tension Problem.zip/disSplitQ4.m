function [W,Q] = disSplitQ4(order,phi,nsubDiv,intType)
% figure
corner = [1 2 3 4 1] ;
node = [-1 -1; 1 -1; 1 1; -1 1] ;

numEdge = size(node,1) ;
cutEdge = [];

%loop on element edges

for iedge = 1:numEdge    
    n1 = corner(iedge);
    n2 = corner(iedge+1);
    hold on
    if( phi(n1)*phi(n2) < 0 )
        r = phi(n1)/(phi(n1)-phi(n2)) ;
        pnt = (1-r)*node(n1,:) + r*node(n2,:) ;
        node = [node; pnt] ;
        %         disp(['Edge is cut by crack     ',num2str(iedge)]) ;
        cutEdge = [cutEdge iedge] ;
        plot(pnt(1),pnt(2),'og');
    end
end %end iedge loop


%check to see if adjacent edges are cut.
%If adjacent edges are, this would mean one of the sub-element will be a polygon and
%the other a triangle. Other feasibility is opposite edges are cut, which
%would mean both the sub-elements are Q4.
nEdge = length(cutEdge);

if(cutEdge(2) == cutEdge(1)+1 | cutEdge(2) == cutEdge(1)+3)
    %     disp('One subelement is polygon')
    if( ismember(cutEdge(1),[1 2]) & ismember(cutEdge(2),[1,2]) )   %side 1 and 2
        tempNode = [node(1,:);node(5,:);node(6,:);node(3,:);node(4,:)] ;
        [geom,iner,cpmo] = polygeom(tempNode(:,1),tempNode(:,2)) ;
        node = [node;geom(2) geom(3)] ;
        tri = [1 7 5;1 7 4;4 7 3;3 7 6;6 7 5;5 6 2] ;
        tri = tricheck(node,tri) ;
    elseif( ismember(cutEdge(1),[2 3]) & ismember(cutEdge(2),[2 3]))  %side 2 and 3
        tempNode = [node(1,:);node(2,:);node(5,:);node(6,:);node(4,:)] ;
        [geom,iner,cpmo] = polygeom(tempNode(:,1),tempNode(:,2)) ;
        node = [node;geom(2) geom(3)] ;
        tri = [1 7 2;1 7 4;4 7 6;6 7 5;5 7 2;3 6 5] ;
        tri = tricheck(node,tri) ;
    elseif( ismember(cutEdge(1),[3 4]) & ismember(cutEdge(2),[3 4]) ) %side 3 and 4
        tempNode = [node(1,:);node(2,:);node(3,:);node(5,:);node(6,:)] ;
        [geom,iner,cpmo] = polygeom(tempNode(:,1),tempNode(:,2)) ;
        node = [node;geom(2) geom(3)] ;
        tri = [1 2 7;2 7 3;7 3 5;5 6 7;6 7 1;4 5 6] ;
        tri = tricheck(node,tri) ;
    elseif( ismember(cutEdge(1),[1 4]) & ismember(cutEdge(2),[1 4]) ) %side 4 and 1
        tempNode = [node(5,:);node(2,:);node(3,:);node(4,:);node(6,:)] ;
        [geom,iner,cpmo] = polygeom(tempNode(:,1),tempNode(:,2)) ;
        node = [node;geom(2) geom(3)] ;
        tri = [1 5 6;5 7 2;6 7 5;6 7 4;4 7 3;7 3 2] ;
        tri = tricheck(node,tri) ;
    end
else
    %     disp('Both subelement are Q4')
    if( cutEdge(1) == 2 & cutEdge(2) == 4 )
        tempNode1 = [node(1,:);node(2,:);node(5,:);node(6,:)] ;
        tempNode2 = [node(6,:);node(5,:);node(3,:);node(4,:)] ;

        [geom,iner,cpmo] = polygeom(tempNode1(:,1),tempNode1(:,2)) ;
        CenPoint1 = [geom(2) geom(3)] ;

        [geom,iner,cpmo] = polygeom(tempNode2(:,1),tempNode2(:,2)) ;
        CenPoint2 = [geom(2) geom(3)] ;
        node = [node; CenPoint1; CenPoint2] ;
        tri = [1 7 2;2 5 7;7 5 6;6 7 1;6 8 5;5 8 3;3 8 4;4 8 6] ;
        tri = tricheck(node,tri) ;
    elseif( cutEdge(1) == 1 & cutEdge(2) == 3)
        tempNode1 = [node(1,:);node(5,:);node(6,:);node(4,:)] ;
        tempNode2 = [node(5,:);node(2,:);node(3,:);node(6,:)] ;

        [geom,iner,cpmo] = polygeom(tempNode1(:,1),tempNode1(:,2)) ;
        CenPoint1 = [geom(2) geom(3)] ;

        [geom,iner,cpmo] = polygeom(tempNode2(:,1),tempNode2(:,2)) ;
        CenPoint2 = [geom(2) geom(3)] ;
        node = [node; CenPoint1; CenPoint2] ;

        tri = [1 7 4;1 7 5;7 5 6;4 7 6;6 8 5;5 8 2;8 2 3;3 8 6] ;
        tri = tricheck(node,tri) ;

    end
end

if( nsubDiv == 0)
    triangles = tri ;
    triNodes = node ;
else
    [triNodes,triangles] = subTriXFEM(node,tri,nsubDiv);
end

node = triNodes ;
tri = triangles ;

% % % ---- plot of the triangulation ------------
% % % -------------------------------------------
% v=get(0,'ScreenSize');
% %figure('Color',[1 1 1],'Position', [0 0 0.4*v(1,3) 0.4*v(1,4)])
% nd=[];
%    for igp = 1 : size(node,1)
%         gpnt = node(igp,:);
%         [N,dNdxi]=lagrange_basis(elemType,gpnt);
%         Gpnt = N' * nodes; % global GP
%         nd = [nd;Gpnt];
%    end
% triplot(tri, nd(:,1),nd(:,2),'g')
% 
% % ------------------------------------------
hold on
% loop over subtriangles to get quadrature points and weights
pt = 1;
for e=1:size(tri,1)
    [w,q] = quadrature(order,intType,2);
    % transform quadrature points into the parent element
    coord = node(tri(e,:),:);
    a = det([coord,[1;1;1]])/2;
    if ( a<0 )  % need to swap connectivity
        coord=[coord(2,:);coord(1,:);coord(3,:)];
        a = det([coord,[1;1;1]])/2;
    end
    
    hold on;
    triplot(tri,node(:,1),node(:,2));
    if ( a~=0 )
        for n=1:length(w)
            N = lagrange_basis('T3',q(n,:));
            Q(pt,:) = N'*coord;
            W(pt,1) = 2*w(n)*a;
            pt = pt+1;
        end
    end

end

hold on
for nnn=1:length(w)
    abc=Q(:,1);
    bbc=Q(:,2);
    plot(abc,bbc,'*r');
end

end


function [ geom, iner, cpmo ] = polygeom( x, y ) 
%POLYGEOM Geometry of a planar polygon
%
%   POLYGEOM( X, Y ) returns area, X centroid,
%   Y centroid and perimeter for the planar polygon
%   specified by vertices in vectors X and Y.
%
%   [ GEOM, INER, CPMO ] = POLYGEOM( X, Y ) returns
%   area, centroid, perimeter and area moments of 
%   inertia for the polygon.
%   GEOM = [ area   X_cen  Y_cen  perimeter ]
%   INER = [ Ixx    Iyy    Ixy    Iuu    Ivv    Iuv ]
%     u,v are centroidal axes parallel to x,y axes.
%   CPMO = [ I1     ang1   I2     ang2   J ]
%     I1,I2 are centroidal principal moments about axes
%         at angles ang1,ang2.
%     ang1 and ang2 are in radians.
%     J is centroidal polar moment.  J = I1 + I2 = Iuu + Ivv

% H.J. Sommer III - 02.05.14 - tested under MATLAB v5.2
%
% code available at:
%    http://www.me.psu.edu/sommer/me562/polygeom.m
% derivation of equations available at:
%    http://www.me.psu.edu/sommer/me562/polygeom.doc
%
% sample data
% x = [ 2.000  0.500  4.830  6.330 ]';
% y = [ 4.000  6.598  9.098  6.500 ]';
% 3x5 test rectangle with long axis at 30 degrees
% area=15, x_cen=3.415, y_cen=6.549, perimeter=16
% Ixx=659.561, Iyy=201.173, Ixy=344.117
% Iuu=16.249, Ivv=26.247, Iuv=8.660
% I1=11.249, ang1=30deg, I2=31.247, ang2=120deg, J=42.496
%
% H.J. Sommer III, Ph.D., Professor of Mechanical Engineering, 337 Leonhard Bldg
% The Pennsylvania State University, University Park, PA  16802
% (814)863-8997  FAX (814)865-9693  hjs1@psu.edu  www.me.psu.edu/sommer/

% begin function POLYGEOM

% check if inputs are same size
if ~isequal( size(x), size(y) ),
  error( 'X and Y must be the same size');
end

% number of vertices
[ x, ns ] = shiftdim( x );
[ y, ns ] = shiftdim( y );
[ n, c ] = size( x );

% temporarily shift data to mean of vertices for improved accuracy
xm = mean(x);
ym = mean(y);
x = x - xm*ones(n,1);
y = y - ym*ones(n,1);

% delta x and delta y
dx = x( [ 2:n 1 ] ) - x;
dy = y( [ 2:n 1 ] ) - y;

% summations for CW boundary integrals
A = sum( y.*dx - x.*dy )/2;
Axc = sum( 6*x.*y.*dx -3*x.*x.*dy +3*y.*dx.*dx +dx.*dx.*dy )/12;
Ayc = sum( 3*y.*y.*dx -6*x.*y.*dy -3*x.*dy.*dy -dx.*dy.*dy )/12;
Ixx = sum( 2*y.*y.*y.*dx -6*x.*y.*y.*dy -6*x.*y.*dy.*dy ...
          -2*x.*dy.*dy.*dy -2*y.*dx.*dy.*dy -dx.*dy.*dy.*dy )/12;
Iyy = sum( 6*x.*x.*y.*dx -2*x.*x.*x.*dy +6*x.*y.*dx.*dx ...
          +2*y.*dx.*dx.*dx +2*x.*dx.*dx.*dy +dx.*dx.*dx.*dy )/12;
Ixy = sum( 6*x.*y.*y.*dx -6*x.*x.*y.*dy +3*y.*y.*dx.*dx ...
          -3*x.*x.*dy.*dy +2*y.*dx.*dx.*dy -2*x.*dx.*dy.*dy )/24;
P = sum( sqrt( dx.*dx +dy.*dy ) );

% check for CCW versus CW boundary
if A < 0,
  A = -A;
  Axc = -Axc;
  Ayc = -Ayc;
  Ixx = -Ixx;
  Iyy = -Iyy;
  Ixy = -Ixy;
end

% centroidal moments
xc = Axc / A;
yc = Ayc / A;
Iuu = Ixx - A*yc*yc;
Ivv = Iyy - A*xc*xc;
Iuv = Ixy - A*xc*yc;
J = Iuu + Ivv;

% replace mean of vertices
x_cen = xc + xm;
y_cen = yc + ym;
Ixx = Iuu + A*y_cen*y_cen;
Iyy = Ivv + A*x_cen*x_cen;
Ixy = Iuv + A*x_cen*y_cen;

% principal moments and orientation
I = [ Iuu  -Iuv ;
     -Iuv   Ivv ];
[ eig_vec, eig_val ] = eig(I);
I1 = eig_val(1,1);
I2 = eig_val(2,2);
ang1 = atan2( eig_vec(2,1), eig_vec(1,1) );
ang2 = atan2( eig_vec(2,2), eig_vec(1,2) );

% return values
geom = [ A  x_cen  y_cen  P ];
iner = [ Ixx  Iyy  Ixy  Iuu  Ivv  Iuv ];
cpmo = [ I1  ang1  I2  ang2  J ];

% end of function POLYGEOM

end

function conn=tricheck(node,conn,verbose)

% FUNCTION
%
%   conn=tricheck(node,conn,verbose)
%
% This function check wether a triangle has a negative Jacobian, and if
% so reorders it so that the the Jacobian is positive.

if ( nargin==2 )
  verbose=0;
end

if ( size(node,2)==3 )
  node=node(:,1:2);
end

count=0;

for e=1:size(conn,1)
  
  sctr=conn(e,:);
  [N,dNdxi]=lagrange_basis('T3',[1/3 1/3]);
  detJ=det(node(sctr,:)'*dNdxi);
  
  if ( detJ < 0 )
    %disp(['NEGATIVE JACOBIAN IN ELEMENT ',num2str(e)])
    conn(e,:)=fliplr(sctr);
    count=count+1;
  elseif ( detJ == 0 )
    disp(['ZERO JACOBIAN IN ELEMENT ',num2str(e),' CANNOT FIX'])
  end
end

if ( verbose )
  disp(['TRICHECK FOUND ',num2str(count),' NEGATIVE JACOBIANS, ALL FIXED'])
end
end
