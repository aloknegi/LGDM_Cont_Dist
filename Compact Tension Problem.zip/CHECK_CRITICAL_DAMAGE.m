function [damage_crit] = CHECK_CRITICAL_DAMAGE(check_damage,damage_crit,omega_crit)

for ie = 1:size(check_damage,1)
    
   damage_gp = check_damage(ie,:);
   damage_count = 0;
   
   for j = 1:size(damage_gp,2) 
       
    omega = damage_gp(1,j); 
    check = round(omega,4);
    
       if check >= omega_crit
        damage_count = damage_count + 1;
       end
   end
   
   if damage_count >= 4
        damage_crit = damage_crit + 1;
   end
end % End of loop on elements

end