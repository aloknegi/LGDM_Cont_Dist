function [tf] = CHECK_DAMAGE_ELEMENT(split_elem,check_damage,omega_crit)

damage_gp = check_damage(split_elem,:);
damage_count = 0;
   
for j = 1:size(damage_gp,2)    
    
   omega = damage_gp(1,j);
   check = round(omega,4);
   
   if check >= omega_crit      
       damage_count = damage_count + 1;
   end
       
end
   
if damage_count >= 2   
 tf = 1;  
else
 tf = 0;
end

end
