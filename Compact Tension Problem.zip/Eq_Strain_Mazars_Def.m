function [eqstrain_nl, deps_de_nl] = Eq_Strain_Mazars_Def(strain_gpt_nonlocal, nu)

    % Plain Stress Criterion
    const = - nu/(1 - nu);
    exx_nl = strain_gpt_nonlocal(1,1); eyy_nl = strain_gpt_nonlocal(2,1); exy_nl = strain_gpt_nonlocal(3,1)/2; 
    ezz_nl = const*(exx_nl + eyy_nl);
    ezx_nl = 0; eyz_nl = 0;
    del = [1; 1; 0];  

    I1 = exx_nl + eyy_nl + ezz_nl;
    I2 = exx_nl*eyy_nl + eyy_nl*ezz_nl + ezz_nl*exx_nl - (exy_nl^2) - (eyz_nl^2) - (ezx_nl^2);    
    I3 = exx_nl*eyy_nl*ezz_nl + 2*exy_nl*eyz_nl*ezx_nl - exx_nl*(eyz_nl^2) - eyy_nl*(ezx_nl^2) - ezz_nl*(exy_nl^2);

    aa = (exx_nl + eyy_nl)/2;
    bb = (exx_nl - eyy_nl)/2;
    p1 = aa + sqrt((bb^2) + ((exy_nl)^2));
    p2 = aa - sqrt((bb^2) + ((exy_nl)^2));
    p3 = const*(exx_nl + eyy_nl);
    den = (exx_nl - eyy_nl);

    if den==0
      alpha = 90;
    else
      p = (exy_nl)/den;
      alpha = 0.5*atand(p);
    end

    % Computing Derivatives

    dp1_dI1 = (p1^2)/(3*(p1^2) - 2*p1*I1 + I2);
    dp1_dI2 = -(p1)/(3*(p1^2) - 2*p1*I1 + I2);
    dp1_dI3 = 1/(3*(p1^2) - 2*p1*I1 + I2);

    dp2_dI1 = (p2^2)/(3*(p2^2) - 2*p2*I1 + I2);
    dp2_dI2 = -(p2)/(3*(p2^2) - 2*p2*I1 + I2);
    dp2_dI3 = 1/(3*(p2^2) - 2*p2*I1 + I2);

    dp3_dI1 = (p3^2)/(3*(p3^2) - 2*p3*I1 + I2);
    dp3_dI2 = -(p3)/(3*(p3^2) - 2*p3*I1 + I2);
    dp3_dI3 = 1/(3*(p3^2) - 2*p3*I1 + I2);

    dI1_dstr = del';
    dI2_dexx = eyy_nl+ezz_nl; dI2_deyy = exx_nl+ezz_nl; dI2_dezz = exx_nl+eyy_nl;
    dI2_dexy = -2*exy_nl; dI2_deyz = -2*eyz_nl; dI2_dezx = -2*ezx_nl; 
    dI3_dexx = eyy_nl + ezz_nl - eyz_nl^2; dI3_deyy = ezz_nl + exx_nl - ezx_nl^2;
    dI3_dezz = exx_nl + eyy_nl - exy_nl^2;
    dI3_dexy = 2*(eyz_nl*ezx_nl - ezz_nl*exy_nl);
    dI3_deyz = 2*(ezx_nl*exy_nl - exx_nl*eyz_nl);
    dI3_dezx = 2*(exy_nl*eyz_nl - eyy_nl*ezx_nl);

    if p1>=0
        pstrn1_pos = p1;
        depspos_de_nl_pos(1,:) = dp1_dI1*dI1_dstr + dp1_dI2*[dI2_dexx dI2_deyy dI2_dexy] + dp1_dI3*[dI3_dexx dI3_deyy dI3_dexy];
    elseif p1<0
        pstrn1_pos = 0;
        depspos_de_nl_pos(1,:) = zeros(1,3);
    end

    if p2>=0
        pstrn2_pos = p2;
        depspos_de_nl_pos(2,:) = dp2_dI1*dI1_dstr + dp2_dI2*[dI2_dexx dI2_deyy dI2_dexy] + dp2_dI3*[dI3_dexx dI3_deyy dI3_dexy];
    elseif p2<0
        pstrn2_pos = 0; 
        depspos_de_nl_pos(2,:) = zeros(1,3);
    end 

    if p3>=0
        pstrn3_pos = p3;
        depspos_de_nl_pos(3,:) = dp3_dI1*dI1_dstr + dp3_dI2*[dI2_dexx dI2_deyy dI2_dexy] + dp3_dI3*[dI3_dexx dI3_deyy dI3_dexy];
    elseif p3<0
        pstrn3_pos = 0; 
        depspos_de_nl_pos(3,:) = zeros(1,3);
    end 

    eqstrain_nl = sqrt(pstrn1_pos^2 + pstrn2_pos^2 + pstrn3_pos^2);
    % deps_depspos = (1/eps_nl)*[pstrn1_pos; pstrn2_pos; pstrn3_pos];
    % deps_de_nl = deps_depspos'*depspos_de_nl_pos;
    deps_de_nl = zeros(1,3);

end


